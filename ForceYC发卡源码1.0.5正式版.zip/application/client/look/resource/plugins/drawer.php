<div class="mdui-drawer mdui-shadow-8" id="drawer">
	<ul class="mdui-list">
        <li class="mdui-list-item mdui-ripple">
            <img src="<?php echo __STATIC__;?>/index/logo1.png" width="180" height="60" align="middle">
        </li>
		<li class="mdui-subheader">菜单</li>
		<a href="<?php echo __URL__;?>" style='text-decoration:none;'>
		<li class="mdui-list-item mdui-ripple">
			<i class="mdui-list-item-icon mdui-icon material-icons"></i>
			<div class="mdui-list-item-content">网站首页</div>
		</li>
		</a>
		<a href="<?php echo __URL__ . 'index.php/query'?>" style='text-decoration:none;'>
			<li class="mdui-list-item mdui-ripple">
				<i class="mdui-list-item-icon mdui-icon material-icons"></i>
				<div class="mdui-list-item-content">卡密查询</div>
			</li>
		</a>
		<a target="_blank" href="http://wpa.qq.com/msgrd?v=3&uin=<?php echo $web['user_qq'];?>&site=qq&menu=yes" style='text-decoration:none;'>
			<li class="mdui-list-item mdui-ripple">
				<i class="mdui-list-item-icon mdui-icon material-icons"></i>
				<div class="mdui-list-item-content">联系站长</div>
			</li>
		</a>
		<li class="mdui-list-item mdui-ripple" mdui-drawer-close>
			<i class="mdui-list-item-icon mdui-icon material-icons"></i>
			<div class="mdui-list-item-content">关闭菜单</div>
		</li>
		<li class="mdui-subheader">友情链接</li>
    <?php 
	$call = Granular::MYSQL('chain')->select();
	foreach ($call as $qr){
	?>
		<a href="<?php echo $qr['chain_http']?>" style='text-decoration:none;' target="_blank">
		<li class="mdui-list-item mdui-ripple">
			<i class="mdui-list-item-icon mdui-icon material-icons"></i>
			<div class="mdui-list-item-content"><?php echo $qr['chain_name']?></div>
		</li>
	    </a>
	<?php }?>
	</ul>
</div>
