<!DOCTYPE html>
<html lang="zh-cn">
<head>
  <meta charset="utf-8"/>
  <meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1,user-scalable=no"/>
  <meta name="keywords" content="<?php echo $web['user_keyword'];?>">
  <meta name="description" content="<?php echo $web['user_description'];?>">
  <link href="//lib.baomitu.com/twitter-bootstrap/3.3.7/css/bootstrap.min.css" rel="stylesheet"/>
  <link href="//lib.baomitu.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet"/>
  <link href="<?php echo __STATIC__;?>/index/nifty.min.css" rel="stylesheet">
  <link href="<?php echo __STATIC__;?>/index/magic-check.min.css" rel="stylesheet">
  <link href="<?php echo __STATIC__;?>/index/pace.min.css" rel="stylesheet">
   <link rel="icon" href="<?php echo __URL__ . $web['user_logo'];?>"/>
  <link rel="stylesheet" href="<?php echo __STATIC__;?>/index/style.css" />
  <!--MDUI Css-->
  <link href="https://cdn.bootcss.com/mdui/0.4.0/css/mdui.min.css" rel="stylesheet">
  <!--BootStrap Css-->
  <link rel="stylesheet" href="http://cdn.static.runoob.com/libs/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="http://cdn.static.runoob.com/libs/jquery/2.1.1/jquery.min.js"></script>
  <script src="http://cdn.static.runoob.com/libs/bootstrap/3.3.7/js/bootstrap.min.js"></script>
  <!--Over-->
  <title><?php echo $web['user_title'];?></title>
  <!--[if lt IE 9]>
    <script src="//lib.baomitu.com/html5shiv/3.7.3/html5shiv.min.js"></script>
    <script src="//lib.baomitu.com/respond.js/1.4.2/respond.min.js"></script>
  <![endif]-->
<style>
body{
img.logo{width:14px;height:14px;margin:0 5px 0 3px;}
.onclick{cursor: pointer;touch-action: manipulation;}
</style>
</head>
<body class="mdui-theme-primary-indigo mdui-theme-accent-pink mdui-drawer-body-left">
  <div id="a2"><?php require 'plugins/drawer.php'; ?></div>
  <div id="index-header" class="mdui-color-pink-accent confession-topbg">
    <div class="position:fixed;top:0; left: 0;width: 960px; height: 60px; background: #f30;">
      <div class="mdui-toolbar mdui-color-pink-accent mdui-appbar-scroll-toolbar-hide">
        <a href="javascript:;" class="mdui-btn mdui-btn-icon" mdui-drawer="{target: '#drawer'}"><i class="mdui-icon material-icons"></i></a>
        <span class="mdui-typo-title"><img src="<?php echo __STATIC__;?>/index/logo.png" width="180" height="60" align="middle"></span>
        <div class="mdui-toolbar-spacer"></div>
      </div>
    </div>
    <div class="index-banner"><span style="font-family: &quot;comic sans ms&quot;;">Dlbrush - 卡密查询</span></div>
  </div>
  <div id="index-center-box" class="">
    <div class="box-text">
    <div class="mdui-table-fluid">
  <table class="mdui-table mdui-table-hoverable">
    <tbody>
      <tr>
        <td><span class="btn btn-danger btn-xs">1</span></td>
        <td>这里是查询卡密的哦~,支持手机号查询,请勿漏泄~</td>
      </tr>
  </table>
</div>

<div class="tab-content">
	<div id="demo-tabs-box-1" class="tab-pane fade active in">
	<div class="modal-body">
				<select id="type" class="mdui-select" mdui-select>
                                       	<option value="1">联系方式</option>
                            			<option value="2">订单号</option>
                                       </select>
				<div class="mdui-textfield">
  <input class="mdui-textfield-input"id="keyword" name="contact" type="text" value="<?php echo $where;?>" placeholder="请填写联系方式/卡号订单号"/>
			</div>
			
		
			<input type="button" id="sea" class="btn mdui-color-pink btn-block" value="点我查询">
	
	
	

<div class="container">
<table>
  <thead>
    <tr>
      <th style="width: 355px;">订单/卡号</th>
      <th style="width: 200px;">联系/支付</th>
      <th style="width: 150px;">购买时间</th>
    </tr> 
  </thead>
  <tbody>
  <?php foreach ($query as $q){?>
    <tr>
      <td>
	  <p><b>订单信息:</b><?php echo $q['order_number'];?></p>
      <p><b>卡密下载:</b><a download="<?php echo $q['order_number'];?>.txt" href="<?php echo $q['order_info']=='1' ? __URL__ ."upload/km/error.txt" : __URL__ ."upload/km/" .$q['order_number']. ".txt";?>">点我下载</p>
	  </td>
      <td>
	 <p><b>联系方式:</b><?php echo $q['order_contact'];?></p>
     <p><b>支付方式:</b><?php if ($q['order_payx']=='alipay'){echo '支付宝';} if ($q['order_payx']=='tenpay'){echo '财付通';} if ($q['order_payx']=='qqpay'){echo 'QQ钱包';} if ($q['order_payx']=='wxpay'){echo '微信';}?></p>
	  </td>
      <td><p><?php echo $q['order_paytime']=='0' ? '未支付' : date("Y/m/d H:i:s",$q['order_paytime']);?></td>
    </tr>
	<?php }?>
  </tbody>
</table>   
</div>
</div>
</div>
</div>
</div>
  <script type="text/javascript">

$('#sea').click(function(){

	var keywrods = $('#keyword').val();
	var type = $('#type').val();	

	if(type=='1'){
			location.href='<?php echo __URL__;?>index.php/query/contact/' + keywrods;
		}
	if(type=='2'){
		location.href='<?php echo __URL__;?>index.php/query/order/' + keywrods;
	}
	
}

		);

</script>
</div>
</div>
<script src="//lib.baomitu.com/jquery/1.12.4/jquery.min.js"></script>
<script src="//lib.baomitu.com/twitter-bootstrap/3.3.7/js/bootstrap.min.js"></script>
<script src="//lib.baomitu.com/jquery-cookie/1.4.1/jquery.cookie.min.js"></script>
<script src="//lib.baomitu.com/layer/2.3/layer.js"></script>
<script src="http://cdn.static.runoob.com/libs/jquery/2.1.1/jquery.min.js"></script>
<script src="http://cdn.bootcss.com/mdui/0.4.0/js/mdui.min.js"></script>
<script src="<?php echo __STATIC__;?>/index/pace.min.js"></script>
<script src="<?php echo __STATIC__;?>/index/jquery.cookie.min.js"></script>

</body>
</html>
