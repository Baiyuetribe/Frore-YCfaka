<!DOCTYPE html>
<html lang="zh-cn">
<head>
  <meta charset="utf-8"/>
  <meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1,user-scalable=no"/>
  <meta name="keywords" content="<?php echo $web['user_keyword'];?>">
  <meta name="description" content="<?php echo $web['user_description'];?>">
  <link href="//lib.baomitu.com/twitter-bootstrap/3.3.7/css/bootstrap.min.css" rel="stylesheet"/>
  <link href="//lib.baomitu.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet"/>
  <link href="<?php echo __STATIC__;?>/index/nifty.min.css" rel="stylesheet">
  <link href="<?php echo __STATIC__;?>/index/magic-check.min.css" rel="stylesheet">
  <link href="<?php echo __STATIC__;?>/index/pace.min.css" rel="stylesheet">
   <link rel="icon" href="<?php echo __URL__ . $web['user_logo'];?>"/>
  <link rel="stylesheet" href="<?php echo __STATIC__;?>/index/style.css" />
  <!--MDUI Css-->
  <link href="https://cdn.bootcss.com/mdui/0.4.0/css/mdui.min.css" rel="stylesheet">
  <!--BootStrap Css-->
  <link rel="stylesheet" href="http://cdn.static.runoob.com/libs/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="http://cdn.static.runoob.com/libs/jquery/2.1.1/jquery.min.js"></script>
  <script src="http://cdn.static.runoob.com/libs/bootstrap/3.3.7/js/bootstrap.min.js"></script>
  <!--Over-->
  <title><?php echo $web['user_title'];?></title>
  <!--[if lt IE 9]>
    <script src="//lib.baomitu.com/html5shiv/3.7.3/html5shiv.min.js"></script>
    <script src="//lib.baomitu.com/respond.js/1.4.2/respond.min.js"></script>
  <![endif]-->
<style>
body{
img.logo{width:14px;height:14px;margin:0 5px 0 3px;}
.onclick{cursor: pointer;touch-action: manipulation;}
</style>
</head>
<body class="mdui-theme-primary-indigo mdui-theme-accent-pink mdui-drawer-body-left">
  <div id="a2"><?php require 'plugins/drawer.php'; ?></div>
  <div id="index-header" class="mdui-color-pink-accent confession-topbg">
    <div class="position:fixed;top:0; left: 0;width: 960px; height: 60px; background: #f30;">
      <div class="mdui-toolbar mdui-color-pink-accent mdui-appbar-scroll-toolbar-hide">
        <a href="javascript:;" class="mdui-btn mdui-btn-icon" mdui-drawer="{target: '#drawer'}"><i class="mdui-icon material-icons"></i></a>
        <div class="mdui-toolbar-spacer"></div>
      </div>
    </div>
    <div class="index-banner"><span style="font-family: &quot;comic sans ms&quot;;">Dlbrush - 个人发卡</span></div>
  </div>
  <div id="index-center-box" class="">
    <div class="box-text">
    <div class="mdui-table-fluid">
  <table class="mdui-table mdui-table-hoverable">
    <tbody>
	<?php 
	$call = Granular::MYSQL('notice')->select();
	foreach ($call as $qr){
	?>
      <tr>
        <td><?php echo $qr['notice_text']?></td>
      </tr>
	<?php }?>
    </tbody>
  </table>
</div><br>
<div class="">
<div class="">

<div class="tab-content">
	<div id="demo-tabs-box-1" class="tab-pane fade active in">
		<div id="a1" class="mdui-shadow-3">
			<div class="">

			</div>
<form action="<?php echo __URL__ . '/index.php/pay'?>" method="post" name="p" target="_blank">
	<div class="modal-body">
		<div class="tab-content">
		<div class="tab-pane fade in active" id="onlinebuy">
		<p>卡密购买</p>
		<div class="mdui-divider"></div>
		<br />
     		<div class="form-group" id="display_selectclass">
				<div class="input-group"><div class="input-group-addon">选择分类</div>
				<select id="cateid" name="cateid" onchange="getCommodity();" class="form-control"><option value="0">请选择分类</option></select>
			</div>
			</div>
			<div class="form-group">
				<div class="input-group"><div class="input-group-addon">选择商品</div>
				<select id="goodid" name="goodid" onchange="getBuy();" class="form-control"><option value="0" class="cdmy">请选择商品</option></select>
			</div></div>
			<div class="form-group">
				<div class="input-group"><div class="input-group-addon" id="inputname">购买数量</div>
				<input type="text" name="quantity" id="quantity" onchange="changequantity(this)" type="number" value="1" placeholder="必填，购买数量" class="form-control" required/>
			</div></div>
			<div class="form-group">
				<div class="input-group"><div class="input-group-addon">商品价格</div>
				<input type="text" id="price" class="form-control" placeholder="NaN" disabled/>
			</div></div>
			<div class="form-group" id="display_left">
				<div class="input-group"><div class="input-group-addon">库存数量</div>
				<input type="text" name="leftcount" id="disc" placeholder="NaN" class="form-control" disabled/>
			</div></div>
			
			
			<div class="form-group">
				<div class="input-group"><div class="input-group-addon" id="inputname">联系方式</div>
				<input type="text" name="contact" placeholder="必填，作为购买者凭证" class="form-control" required/>
			</div></div>
			<style type="text/css">
            textarea {
            resize: none;
            }
             </style>

            <textarea rows="6" id="nrtext" placeholder="购买须知" class="form-control" readonly="true"></textarea>
            <br />
			<div class="mdui-divider"></div>
			<br />
			<div id="alert_frame" class="" style="font-weight: bold;"></div>
			<input type="submit" id="submit_buy" class="btn mdui-color-pink btn-block" value="立即购买">
		</div>

		</div>
	</div>
	<script type="text/javascript">
			//获取分类

    		$.get("<?php echo __URL__ . '/index.php/getCategory';?>", function(result){
				
				for(var i = 0; i<result.data.length;i++){
		
					$("#cateid").append('<option value="'+ result.data[i].id +'">' + result.data[i].category_name + '</option>');
					
				}
	  		});


	  		//获取商品
	  		function getCommodity(){
		  		var sid = $('#cateid').val();
		  			$.get("<?php echo __URL__ . '/index.php/getCommodity/id/';?>" + sid, function(result){
		  				$("option").remove(".cdmy");
		  				$("#goodid").append('<option value="0" class="cdmy">请选择商品</option>');
						for(var i = 0; i<result.data.length;i++){
							$("#goodid").append('<option class="cdmy" value="'+ result.data[i].id +'">' + result.data[i].shop_name + '</option>');
						}
			  		});
			}

			//buyId
			var buyId = 0;
	  		//初始化商品全局价格
			var price = 0;
			//初始化商品数量
			var nums = 0;
			//初始化全局优惠规则 
			var disc = new Array();
			//初始化全局批发开关
			var discount = 0;
			//购买总价
			var priceBuy = 0;


			//商品详细获取
			// function getBuy(){
			// 	var sid = $('#goodid').val();

	  // 			$.get("<?php //echo __URL__ . '/index.php/getBuy/id/';?>" + sid, function(result){
	  // 				//设置buyid
	  // 				buyId = result.data.id;

	  // 				//设置单价显示
	  // 				price = result.data.shop_price;
	  // 				$('#price').val(price);
	  // 				priceBuy = price;

	  // 				if(discount == 1){
		 //  				$('#disc').val(result.msg+'张 ( 批发自动降价已开启 )');
						
			//   		}else{
			//   			$('#disc').val(result.msg+'张');
			// 	  	}
	  				
					
		 //  		});
			// }
          function getBuy(){
                  var sid = $('#goodid').val();

                    $.get("<?php echo __URL__ . '/index.php/getBuy/id/';?>" + sid, function(result){
                      //设置buyid
                      buyId = result.data.id;

                      //设置单价显示
                      price = result.data.shop_price;
                      nrtext = result.data.shop_text;
                      $('#price').val(price);
                      $('#nrtext').val(nrtext);
                      priceBuy = price;
                      if(discount == 1){
                        $('#disc').val(result.msg+'张 ( 批发自动降价已开启 )');
                      
                      }else{
                        $('#disc').val(result.msg+'张');
                      }
                      
                    
                    });
                }
            //数量修改 这里就是修改价格的
            function changequantity(obj){
                var nm = $(obj).val();//数量
                // var danjia = $('#price').val();//单价
                var he = erge(nm*price,2);
                // priceBuy = parseInt(nm)*price;
                if(discount == 1){
                    $('#price').val(he);
                } else {
                    $('#price').val(he);
                }
            }
            //取小数点2位 
            function erge(he,num){
              return parseFloat(he).toFixed(num)
            }
			// //数量修改 这里就是修改价格的
			// function changequantity(obj){
			// 	var nm = $(obj).val();

			// 	$('#price').val(parseInt(nm)*$('#price').val());

			// 	priceBuy = parseInt(nm)*price;
				
			// 	if(discount == 1){
	
			// 		for(var i = 0;i<disc.length;i++){
			// 			var pxl = disc[i].split(",");

			// 			if(parseInt(nm) >= parseInt(pxl[0])){
			// 				$('#price').val(parseInt(nm)*pxl[1]);
			// 				priceBuy = parseInt(nm)*pxl[1];
			// 			}
			// 		}
					
		
		 //  		}
			// }
        
        

    </script>
</form>
</div>
</div>
</div>
</div>
</div>
<br>
<div class="mdui-table-fluid">
  <table class="mdui-table mdui-table-hoverable">
    <tbody>
      <tr>
        <td><b>个人发卡网址统计</b></td>
      </tr>
    </tbody>
  </table>
 <div class="mdui-col-sm-8 mdui-col-md-6" style="text-align: center;">
      <div class="mdui-card">
        <div class="mdui-card-media">
          <img src="http://wx2.sinaimg.cn/mw690/0060lm7Tly1fqk992ol19j30xc0go11h.jpg"/>
          <div class="mdui-card-media-covered">
            <div class="mdui-card-primary">
              <div class="mdui-card-primary-title"><span class="text-semibold" id="count_money"><?php echo round($money[0]['money'],2);?> </span>元</div>
              <div class="mdui-card-primary-subtitle">累计交易金额</div>
            </div>
          </div>
        </div>
      </div>
    </div>
    <div class="mdui-col-sm-8 mdui-col-md-6" style="text-align: center;">
      <div class="mdui-card">
        <div class="mdui-card-media">
          <img src="http://wx1.sinaimg.cn/mw690/0060lm7Tly1fqk9cwjl9jj30xc0go47o.jpg"/>
          <div class="mdui-card-media-covered">
            <div class="mdui-card-primary">
              <div class="mdui-card-primary-title"><span class="text-semibold" id="count_money1"><?php echo round($order[0]['money'],2);?></span> 元</div>
              <div class="mdui-card-primary-subtitle">今日交易金额</div>
            </div>
          </div>
        </div>
      </div>
    </div>

    <br>

    <div class="mdui-col-sm-8 mdui-col-md-6" style="text-align: center;">
      <div class="mdui-card">
        <div class="mdui-card-media">
          <img src="http://wx4.sinaimg.cn/mw690/0060lm7Tly1fqk9dfsx3wj30xc0gowmy.jpg"/>
          <div class="mdui-card-media-covered">
            <div class="mdui-card-primary">
              <div class="mdui-card-primary-title"><span class="text-semibold" id="count_orders"><?php echo $query;?> </span>条</div>
              <div class="mdui-card-primary-subtitle">购买完成总数</div>
            </div>
          </div>
        </div>
      </div>
    </div>

    <div class="mdui-col-sm-8 mdui-col-md-6" style="text-align: center;">
      <div class="mdui-card">
        <div class="mdui-card-media">
          <img src="http://wx2.sinaimg.cn/mw690/0060lm7Tly1fqk9dg67f2j30xc0goajg.jpg"/>
          <div class="mdui-card-media-covered">
            <div class="mdui-card-primary">
              <div class="mdui-card-primary-title"><span class="text-semibold" id="count_orders2"><?php echo $order[0]['count'];?> </span>条</div>
              <div class="mdui-card-primary-subtitle">今日购买总数</div>
            </div>
          </div>
        </div>
      </div>
    </div>
    <div class="mdui-col-sm-8 mdui-col-md-6">
	<br>
    </div>
</div>
  
</div>
</div>
<script src="//lib.baomitu.com/jquery/1.12.4/jquery.min.js"></script>
<script src="//lib.baomitu.com/twitter-bootstrap/3.3.7/js/bootstrap.min.js"></script>
<script src="//lib.baomitu.com/jquery-cookie/1.4.1/jquery.cookie.min.js"></script>
<script src="//lib.baomitu.com/layer/2.3/layer.js"></script>
<script src="http://cdn.static.runoob.com/libs/jquery/2.1.1/jquery.min.js"></script>
<script src="http://cdn.bootcss.com/mdui/0.4.0/js/mdui.min.js"></script>
<script src="<?php echo __STATIC__;?>/index/pace.min.js"></script>
<script src="<?php echo __STATIC__;?>/index/jquery.cookie.min.js"></script>

</body>
</html>
