<!DOCTYPE html>
<html lang="en" class="no-js">
	<head>
		<meta charset="UTF-8" />
		<meta http-equiv="X-UA-Compatible" content="IE=edge"> 
		<meta name="viewport" content="width=device-width, initial-scale=1"> 
		<title>YcPAY安装系统 - 支付小助手!</title>
		<link rel="stylesheet" type="text/css" href="<?php echo __STATIC__ . '/install/'?>css/normalize.css" />
		<link rel="stylesheet" type="text/css" href="<?php echo __STATIC__ . '/install/'?>css/demo.css" />
		<link rel="stylesheet" type="text/css" href="<?php echo __STATIC__ . '/install/'?>css/component.css" />
		<script src="<?php echo __STATIC__ . '/install/'?>js/modernizr.custom.js"></script>
		<script src="<?php echo __STATIC__;?>/mix/jquery.js" type="text/javascript"></script>
	</head>
	<body>
		<div class="container">
			<header class="codrops-header">
				<h1>第一次使用，你只需要几步，就可以完成最后部署..</h1>	
			</header>
			<section>
				<form id="theForm" class="simform" autocomplete="off">
					<div class="simform-inner">
						<ol class="questions">
							<li>
								<span><label for="q1">您的MySQL数据库地址是多少?</label></span>
								<input id="q1" type="text" value="127.0.0.1" name="server"/>
							</li>
							<li>
								<span><label for="q2">您的数据库用户名是多少?</label></span>
								<input id="q2"  type="text" name="username"/>
							</li>
							<li>
								<span><label for="q3">您的数据库用户密码是多少?</label></span>
								<input id="q3"  type="text" name="pwd"/>
							</li>
							<li>
								<span><label for="q4">您想将小助手安装在那个数据库?</label></span>
								<input id="q4" type="text" name="db"/>
							</li>
						</ol><!-- /questions -->
						<button class="submit" type="submit">提交</button>
						<div class="controls">
							<button class="next"></button>
							<div class="progress"></div>
							<span class="number">
								<span class="number-current"></span>
								<span class="number-total"></span>
							</span>
							<span class="error-message"></span>
						</div><!-- / controls -->
					</div><!-- /simform-inner -->
					<span class="final-message"></span>
				</form><!-- /simform -->			
			</section>
		</div><!-- /container -->
		<script src="<?php echo __STATIC__ . '/install/'?>js/classie.js"></script>
		<script src="<?php echo __STATIC__ . '/install/'?>js/stepsForm.js"></script>
		<script>
			var theForm = document.getElementById( 'theForm' );

			new stepsForm( theForm, {
				onSubmit : function( form ) {
					// hide form
					classie.addClass( theForm.querySelector( '.simform-inner' ), 'hide' );

					/*
					form.submit()
					or
					AJAX request (maybe show loading indicator while we don't have an answer..)
					*/

					// let's just simulate something...
					var messageEl = theForm.querySelector( '.final-message' );

					var data = $('#theForm').serialize();
					$.ajax({
	                    type: "POST",
	                    dataType: "json",
	                    url: '<?php echo __URL__;?>index.php/installService',
	                    data: data,
	                    success: function (data) {

		                    
		                   messageEl.innerHTML = '谢谢你使用YcPAY支付小助手,安装已完成,如果自动跳转首页还是安装,那就是安装失败,稍等自动跳转登录..';
			                
	                    	
	                    },
	                    error: function(data) {
	                    	messageEl.innerHTML = '谢谢你使用YcPAY支付小助手,安装已完成,如果自动跳转首页还是安装,那就是安装失败,稍等自动跳转登录..';
	                     }
					 });

					
					classie.addClass( messageEl, 'show' );

					setTimeout(function(){location.href='<?php echo __URL__?>';},2000);
				}
			} );
		</script>
	</body>
</html>