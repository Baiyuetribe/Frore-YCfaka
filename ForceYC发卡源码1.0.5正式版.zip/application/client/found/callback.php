<?php
class callback{
	//回调操作
	function mains(){

		require_once("yanyu_notify.class.php");
		 $passagewayMysql = Granular::MYSQL('passageway')->select("passageway_state='1'")[0];
		
		//获取回调订单号
        $order = Granular::REQUEST('get', 'out_trade_no','xss');
		//开始进行金额提交
        $moeny = Granular::REQUEST('get', 'money','xss');//金额
       //交易方式
        $type = Granular::REQUEST('get', 'type','xss');//交易方式
		//连接数据表order
		$orderMysql = Granular::MYSQL('order');
		//连接数据表user
		$userMysql = Granular::MYSQL('user')->select();
		

$alipay_config['partner'] = $passagewayMysql['passageway_username'];
//商户KEY
$alipay_config['key']= $passagewayMysql['passageway_key'];
//签名方式 不需修改
$alipay_config['sign_type']    = strtoupper('MD5');
//字符编码格式 目前支持 gbk 或 utf-8
$alipay_config['input_charset']= strtolower('utf-8');
//访问模式,根据自己的服务器是否支持ssl访问，若支持请选择https；若不支持请选择http
$alipay_config['transport']    = 'http';
//支付服务器请求地址
$alipay_config['apiurl']    = $passagewayMysql['passageway_website'];

$alipayNotify = new AlipayNotify($alipay_config);
$verify_result = $alipayNotify->verifyNotify();

if($verify_result) {//验证成功
	/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	//请在这里加上商户的业务逻辑程序代

	
	//——请根据您的业务逻辑来编写程序（以下代码仅作参考）——
	
    //获取支付宝的通知返回参数，可参考技术文档中服务器异步通知参数列表
	
	//商户订单号

	$out_trade_no = $order;

	//彩虹易支付交易号

	$trade_no = Granular::REQUEST('get', 'trade_no','xss');

	//交易状态
	$trade_status = Granular::REQUEST('get', 'trade_status','xss');

	//支付方式
	$type = Granular::REQUEST('get', 'type','xss');


	if ($_GET['trade_status'] == 'TRADE_SUCCESS') {
		//判断该笔订单是否在商户网站中已经做过处理
			//如果没有做过处理，根据订单号（out_trade_no）在商户网站的订单系统中查到该笔订单的详细，并执行商户的业务程序
			//请务必判断请求时的total_fee、seller_id与通知时获取的total_fee、seller_id为一致的
			//如果有做过处理，不执行商户的业务程序
				
		//注意：
		//付款完成后，支付宝系统发送该交易状态通知

    }

	//——请根据您的业务逻辑来编写程序（以上代码仅作参考）——
        
	//-----------------
	//查询数据库订单号
		$orderCall = $orderMysql->select("order_number={$order} and order_moeny={$moeny} and order_state=1");
	    //订单是否有异常
        if (!is_array($orderCall[0])) exit('error:150');

        //进入库存取出卡密
        $ry = Granular::MYSQL('repertory');
        $rydb = $ry->select("repertory_shopid={$orderCall[0]['order_shopid']} and repertory_state=1");
  		
        //卡密不足情况下解决问题
        if (count($rydb) == 0){
            //处理错误信息
            $orderMysql->update(array("order_info"=>"订单处理失败,请联系客服解决","order_paytime"=>time(),"order_state"=>2), "id={$orderMx[0]['id']}");
            exit('error');
        }else{
            $cami = '';
            //卡密充足下开始取卡
            for ($i=0;$i<intval($orderCall[0]['order_info']);$i++){
                $cami .= $rydb[$i]['repertory_card'] . PHP_EOL;
                //置已出卡
                $ry->update(array("repertory_state"=>2,"repertory_contact"=>$orderCall[0]['order_contact'],"repertory_paytime"=>time()), "id={$rydb[$i]['id']}");
            }
          
           $file = __ROOT__ . "/upload/km/" . $order . '.txt';
           file_put_contents($file,$cami."\r\n");
          
             //修改数据信息
            $orderMysql->update(array("order_info"=>trim($cami,PHP_EOL),"order_paytime"=>time(),"order_payx"=>$type,"order_state"=>2), "id={$orderCall[0]['id']}");
           exit('success');
        }
	
	/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
}
else {
    //验证失败
    echo "fail";
}
   
	}

}
?>