<?php
class pay{
    //查询订单
    function query(){
        $where = null;

        //订单号查询
        $card = addslashes(Granular::REQUEST('get', 'order','xss'));
         $WebInfo = Granular::MYSQL('user')->select('id=1');
        //联系方式查询
        $contact = addslashes(Granular::REQUEST('get', 'contact','xss'));

        if (!empty($card) || !empty($contact)){
            
            if (!empty($card)){
                $where = "order_number={$card}";
            }
            
            if (!empty($contact)){
                $where = "order_contact='{$contact}'";
            }
            
            $query = Granular::MYSQL('order')->select($where);
            
        }else{
            $query = array();
        }

        Granular::IMPORT('query',array("query"=>$query,"web"=>$WebInfo[0]));
    }
    
    //自动发卡
    function auto(){
        //订单号
        $orderNumber = Granular::REQUEST('get', 'out_trade_no','xss');
        
        $orderMysql = Granular::MYSQL('order');
        
        $orderCall = $orderMysql->select("order_number={$orderNumber}");
        
        if (!is_array($orderCall[0])) exit('订单不存在');

        if ($orderCall[0]['order_state'] != 2)  exit('订单有误');
        
        Granular::IMPORT('auto',array("order"=>$orderCall[0]));
    }
    
    function buy() {
        
  
        //需求信息 ： 商品id，数量，联系方式，优惠卷，支付方式
        
        //检测支付方式是否正确
        $pay = intval(Granular::REQUEST('post', 'pay', 'xss'));
        $user = Granular::MYSQL('user')->select();
        //检测联系方式是否填写
        $contact = strip_tags(Granular::REQUEST('post', 'contact', 'xss'));
        if (strlen($contact) < 6)  exit('联系方式不能低于6位字符串!<script>setTimeout(function(){window.close();},1000);</script>');
        
        //检测商品是否存在
        $gid = intval(Granular::REQUEST('post', 'goodid','xss'));
        if ($gid == 0) exit('请选择商品后再进行购买!<script>setTimeout(function(){window.close();},1000);</script>');
        
        //读取商品配置
        $call = Granular::MYSQL('shop')->select("id={$gid}");
        if (!is_array($call[0])) exit('该商品不存在!<script>setTimeout(function(){window.close();},1000);</script>');
        
        //计算数量
        $num = intval(Granular::REQUEST('post', 'quantity','xss'));
        if ($num < 1)  exit('商品数量不能低于1!<script>setTimeout(function(){window.close();},1000);</script>');
        
        //库存计算
        $ry = Granular::MYSQL('repertory')->select("repertory_shopid={$call[0]['id']}");
        if ($num > count($ry)) exit('库存不足于你购买的数量,请尝试降低购买数量!<script>setTimeout(function(){window.close();},1500);</script>');
        
        //全部处理完毕，开始计算价格
        
        //初始化购买金额
        $moeny = 0;
        
        //初始化优惠卷抵扣金额
        $vm = 0;
        
        //初始化批发抵扣金额
        $disc = 0;
        
        //计算批量价格
        if ($call[0]['shop_discount'] == 1){
            //初始化普通计算
            $moeny = ($num*$call[0]['shop_price'])-$vm;
            //分隔规则
            $discPe = explode(PHP_EOL, $call[0]['shop_disc']);
            for ($i = 0;$i < count($discPe); $i++){
                $injeck = explode(",", $discPe[$i]);
                if ($num >= intval($injeck[0])){
                    $moeny = ($num*intval($injeck[1]))-$vm;
                }
            }
            
        }else{
            //没有开启批量价格
            $moeny = ($num*$call[0]['shop_price'])-$vm;
        }
        
        //初始化二维码地址
        $qrcodeUrl = '';
        
        //初始化支付金额
        $payMoney = $moeny;
        
        //是否提示支付
        $msgCall = 0;
        
        $oderMysql = Granular::MYSQL('order');
        //拉完通道开始创建监控订单
        $orderNum = date("Ymdhis",time()) . mt_rand(10000, 99999);//订单号

        //创建订单
        $CreateOrder = $oderMysql->insert(array(
            "order_number"=>$orderNum,
            "order_shopid"=>$call[0]['id'],
            "order_info"=>$num,
            "order_creatime"=>time(),
            "order_paytime"=>0,
            "order_moeny"=>$payMoney,
            "order_state"=>1,
            "order_contact"=>$contact
        ));
        
        if ($CreateOrder){
            //订单创建完毕后销毁优惠卷
            if ($call[0]['shop_coupon'] == 1){
                if (!empty($volume)){
                    //销毁优惠卷
                    $volumeMysql->update(array("coupon_state"=>2,"coupon_usetime"=>time()), "id={$volumeDb[0]['id']}");
                }
            }
		    $shopMysql = Granular::MYSQL('shop')->select("id={$call[0]['id']}")[0]['shop_name'];
		    $userMysql = Granular::MYSQL('user')->select("id=1")[0]['user_title'];
		    $passagewayMysql = Granular::MYSQL('passageway')->select("passageway_state='1'")[0];
			if($passagewayMysql == null){
				exit('请联系管理员开启支付通道后在进行购买');
			}			
            Granular::IMPORT("gateway",array(
			"qrcode"=>$qrcodeUrl,
			"order"=>$orderNum,
			"moeny"=>$payMoney,
			"msg"=>$msgCall,
			"orderNumber"=>$orderNum,
			"alleywayId"=>$alleywayId,
			"pay"=>$pay,
			"user"=>$user,
			"shopMysql"=>$shopMysql,
			"userMysql"=>$userMysql,
			"passagewayMysql"=>$passagewayMysql
			));
        }
        
    }
}