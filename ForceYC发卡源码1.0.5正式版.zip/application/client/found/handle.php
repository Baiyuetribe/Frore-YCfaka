<?php
class handle{
    //商品分类获取
    function getCategory(){
        //初始化数据库
        $call = Granular::MYSQL('category');
        //唯一ID查找
        $where = null;
        
        $uniqid = Granular::REQUEST('get', 'id','sql');
                
        if (!empty($uniqid)) {
            $where = "category_uniqid='{$uniqid}'";
        }
        
        $getCategory = $call->select($where,null,'id','desc',null,'id,category_name');
        
        Granular::JSON(1, '商品分类', $getCategory);
        
    }
    
    //商品获取
    function getCommodity(){
        //初始化数据库
        $call = Granular::MYSQL('shop');
        //唯一ID查找
        $where = null;
        
        $uniqid = Granular::REQUEST('get', 'id','sql');
        
        if (!empty($uniqid)) {
            $where = "shop_cateid={$uniqid}";
        }else{
            Granular::JSON(-2, '无分类');
        }
        
        $getCommodity = $call->select($where,null,'shop_rank','desc',null,'id,shop_name');
        
        Granular::JSON(1, '商品获取', $getCommodity);
    }
    
    //详细信息获取
    function getBuy(){
        //初始化数据库
        $call = Granular::MYSQL('shop');
        //唯一ID查找
        $where = null;
        
        $uniqid = Granular::REQUEST('get', 'id','sql');
        
        if (!empty($uniqid)) {
            $where = "id={$uniqid}";
        }else{
            Granular::JSON(-2, 'ID出错');
        }
        
        //获取商品
        $getCommodity = $call->select($where,null,'id','desc',null,'id,shop_name,shop_price,shop_text');
        
        //获取库存
        $getRepertory = Granular::MYSQL('repertory')->select("repertory_shopid={$getCommodity[0]['id']} and repertory_state=1");
        
        Granular::JSON(1, count($getRepertory), $getCommodity[0]);
    }
   
}