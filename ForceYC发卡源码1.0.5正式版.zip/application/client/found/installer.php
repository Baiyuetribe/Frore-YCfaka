<?php
class installer{
    //运行
    function run(){
        //检测是不是已经安装过了
        if (file_exists('./config.php')) Granular::JUMP(__URL__, 0);

        $server = Granular::REQUEST('post', 'server','xss');

        $username = Granular::REQUEST('post', 'username','xss');
        
        $pwd = Granular::REQUEST('post', 'pwd', 'xss');
        
        $db = Granular::REQUEST('post', 'db', 'xss');
        //载入db库
        include_once __INTERFACE__ . 'DB.php';

        $DBx32 = new DBManage($server, $username, $pwd, $db, "utf8");
        
        $DBx32->restore('./instal.sql');
        
        unlink('./instal.sql');
        
        $config = <<<Eof
<?php
function INTO(\$DB){
    return array(
        "HOST" => "{$server}",//数据库服务器
        "PORT" => '3306',//数据库端口
        "USER" => "{$username}",//用户名
        "PASS" => "{$pwd}",//密码
        "DB" => "{$db}",//数据库名称
        "CHARSET" => "utf8",//数据库编码
        "PREFIX" => "wintpay_",//表前缀
        "TABLE" => \$DB //该项不能更改
    );
}
?>
Eof;
        file_put_contents("config.php", $config);
        
        Granular::JSON(1, '安装完成');

    }
}