<?php
class sql{
    function column($Tb,$page,$where=null,$desc=null,$ap='*') {
        //初始化数据库的表
        $INFO = INTO($Tb);
        //for加入前缀
        $mysql = Granular::MYSQL($Tb);
        //加载where关键词
        //设计 $Where =  array('type'=>true,'dary'=>'and','cont'=>'=','word'=>array('key'=>'writings_title','val'=>'123')),
        $_where = '';
        if (is_array($where)){
            foreach ($where as $wh){
                if ($wh['type']){
                    $val = "'".$wh['word']['val']."'";
                }else{
                    $val = $wh['word']['val'];
                }
            
                $_where .= $wh['word']['key'] . ' ' . $wh['cont'] . ' ' . $val . ' ' . $wh['dary'] . ' ';
            }
        }
        $_where = trim(trim($_where),"and");
        //end $where
        //加载排序规则
        //设计$desc  = array('desc'=>'id','by'=>'desc')
        
        //设计分页规则
        //设计$page = array('num'=>$_GET['page'],'all'=>15)
        //取出总数
        if (!empty($_where)){
            $countwhere = "where ". $_where;
        }
        $query_count = $mysql->sql("select count(id) as c from {$INFO['PREFIX']}{$Tb} {$countwhere}");//所有记录数量
        $query_count = $query_count[0]['c'];
        //计算总页数
        $page_count = ceil($query_count / $page['all']);
        //计算当前页面大于总页数
        if ($page_count <= $page['num']) $page['num'] = $page_count;
        //计算当前页面小于1
        if ($page['num'] <= 1) $page['num'] = 1;
        //计算当前页码
        $current_page = ($page['num']-1) * $page['all']; 
        //查询列表
        $data = $mysql->select($_where, null, $desc['desc'],$desc['by'], "{$current_page},{$page['all']}", $ap);
        return array('data'=>$data,'info'=>array('current'=>$page['num'],'count'=>$query_count,'page'=>$page_count));
    }
    
    function relyon($Tb,$id) {
        $mysql = Granular::MYSQL($Tb);
        $data = $mysql->select("id={$id}");
        return $data[0];
    }
    
    //通用删除id
    function delete($Tb,$Id){
        $call = Granular::MYSQL($Tb);
        $pxid = explode(",", trim($Id,","));
        $unm = 0;
        for ($i=0;$i<count($pxid);$i++){
            $delete = $call->delete("id={$pxid[$i]}");
            if ($delete){
                $unm = $unm+1;
            }
        }
        return $unm;
    }
}