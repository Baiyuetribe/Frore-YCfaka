<?php
class client{
    //首页
    function index(){
        if (!file_exists('./config.php')) Granular::JUMP(__URL__ . 'index.php/install', 0);
        $WebInfo = Granular::MYSQL('user')->select('id=1');
      
        $nowTime = strtotime(date("Y-m-d",time()) . ' 00:00:00');
        $order = Granular::MYSQL('order')->sql("select sum(order_moeny) as money,count(id) as count from wintpay_order where order_paytime>{$nowTime}");
        $money = Granular::MYSQL('order')->sql("select sum(order_moeny) as money,count(id) as count from wintpay_order where order_state=2");
		$query = Granular::MYSQL('order')->sql("select count(id) as c from wintpay_order where order_state=2")[0]['c'];
		$list = Granular::MYSQL('order')->select();
        Granular::IMPORT('index',array(
		"web"=>$WebInfo[0],
        "order"=>$order,
         "money"=>$money,
		"query"=>$query,
		"list"=>$list
		));
    }
    //获取分类
    function getCategory(){
        $category = Granular::MODEL('handle')->getCategory();
        echo $category;
    }
    
    //获取商品
    function getCommodity(){
        $getCommodity = Granular::MODEL('handle')->getCommodity();
        echo $getCommodity;
    }
    
    //获取详细商品
    function getBuy(){
        $getBuy = Granular::MODEL('handle')->getBuy();
        echo $getBuy;
    }
    
    //监听操作并且创建订单
    function pay(){
        //创建支付实例
        Granular::MODEL('pay')->buy();
    }
    //回调信息
    function callback(){
        //创建支付实例
        Granular::MODEL('callback')->mains();
    }    
    //自动发卡
    function auto(){
        Granular::MODEL('pay')->auto();
    }
    
    //查询
    function query(){
        Granular::MODEL('pay')->query();
    }
    
    //监控 - 提交订单
    function put(){
        Granular::MODEL('service')->put();
    }
    
    //监控 - 监听
    function listen(){
        Granular::MODEL('service')->listen();
    }
    
    //安装界面
    function install(){
        if (file_exists('./config.php')) Granular::JUMP(__URL__, 0);
        Granular::IMPORT('install');
    }
    
    //安装服务
    function installService(){
        Granular::MODEL('installer')->run();
    }
    
}