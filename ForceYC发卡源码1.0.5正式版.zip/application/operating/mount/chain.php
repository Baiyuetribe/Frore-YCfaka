<?php
class chain{
    function add(){
        Granular::MODEL('user')->vlogin();
        Granular::MODEL('chains')->add();
    }
    function delete(){
        Granular::MODEL('user')->vlogin();
        Granular::MODEL('chains')->delete();
    }
    function edit(){
        Granular::MODEL('user')->vlogin();
        Granular::MODEL('chains')->edit();
    }
}