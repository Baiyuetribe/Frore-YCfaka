<?php
class notice{
    function add(){
        Granular::MODEL('user')->vlogin();
        Granular::MODEL('notices')->add();
    }
    function delete(){
        Granular::MODEL('user')->vlogin();
        Granular::MODEL('notices')->delete();
    }
    function edit(){
        Granular::MODEL('user')->vlogin();
        Granular::MODEL('notices')->edit();
    }
}