<?php
class repertory{
    function add() {
        Granular::MODEL('user')->vlogin();
        Granular::MODEL('ry')->add();
    }   
    //删除
    function delete(){
        Granular::MODEL('user')->vlogin();
        $Id = Granular::REQUEST('get', 'id', 'sql');
        $state = Granular::MODEL('query')->delete('repertory',$Id);
        Granular::JSON(1, '批处理完成,共删除:' . $state . "个卡密");
    }
}