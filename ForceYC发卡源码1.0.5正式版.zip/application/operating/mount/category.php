<?php
//添加分类
class category{
    function add(){
        Granular::MODEL('user')->vlogin();
        Granular::MODEL('cate')->add();
    }
    function edit(){
        Granular::MODEL('user')->vlogin();
        $qr = Granular::MODEL('cate')->edit();
    }
    function delete(){
        Granular::MODEL('user')->vlogin();
        $qr = Granular::MODEL('cate')->delete();
    }
}

?>