<?php
class payservice{
    //登录服务  - 连接数据库
    function login(){
        Granular::MODEL('user')->login();
    }
    //资料修改服务
    function edit(){
        Granular::MODEL('user')->edit();
    }
    //注销登录
    function logout(){
        $_SESSION['sid'] = 0;
        Granular::JUMP(__URL__ . '/index/login', 1, '正在安全退出中..');
    }
    
    //订单删除事务
    function orderDelete(){
        Granular::MODEL('user')->vlogin();
        $Id = Granular::REQUEST('get', 'id', 'sql');
        $state = Granular::MODEL('query')->delete('order',$Id);
        Granular::JSON(1, '批处理完成,共删除:' . $state . "个订单");
    }
}
?>