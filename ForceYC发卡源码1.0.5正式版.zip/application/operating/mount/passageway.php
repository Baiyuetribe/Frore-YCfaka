<?php
class passageway{
    function add(){
        Granular::MODEL('user')->vlogin();
        Granular::MODEL('payment')->add();
    }
    function delete(){
        Granular::MODEL('user')->vlogin();
        Granular::MODEL('payment')->delete();
    }
    function edit(){
        Granular::MODEL('user')->vlogin();
        Granular::MODEL('payment')->edit();
    }
    function state(){
        Granular::MODEL('user')->vlogin();
        Granular::MODEL('payment')->state();
    }
}