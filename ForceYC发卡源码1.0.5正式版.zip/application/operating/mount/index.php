<?php
class index{
    
    //登录界面
    function login(){
        if (is_array($_SESSION['sid'])) {
            if (count($_SESSION['sid']) == 2){
                Granular::JUMP(__URL__ . '/index/home', 1, '请稍后,自动登录中..');
            }
        }
        Granular::IMPORT('login');
    }
    
    //面板
    function home(){
        Granular::MODEL('user')->vlogin();
        $user = Granular::MYSQL('user')->select("user_username='{$_SESSION['sid']['username']}'");
        Granular::IMPORT('home',array("user"=>$user));
    }
    //商品分类
    function category(){
        Granular::MODEL('user')->vlogin();
        $query = Granular::MODEL('cate')->query();
        Granular::IMPORT('category',array("query"=>$query));
    }
    # 商品分类修改
    function editct(){
        Granular::MODEL('user')->vlogin();
        $qrd = Granular::MODEL('query')->relyon('category',Granular::REQUEST('get', 'id', 'sql'));
        Granular::IMPORT('editct',array('qrd'=>$qrd));
    }
    //商品
    function shop(){
        Granular::MODEL('user')->vlogin();
        $query = Granular::MODEL('sp')->query();
        Granular::IMPORT('shop',array("query"=>$query));
    }
    # 添加商品
    function shopAdd(){
        Granular::MODEL('user')->vlogin();
        $query = Granular::MYSQL('category')->select();
        Granular::IMPORT('shopAdd',array('query'=>$query));
    }
    # 修改商品
    function shopEdit(){
        Granular::MODEL('user')->vlogin();
        $query = Granular::MYSQL('category')->select();
        $id = Granular::REQUEST('get', 'id', 'sql');
        $call = Granular::MYSQL('shop')->select("id={$id}");
        Granular::IMPORT('shopEdit',array('query'=>$query,"call"=>$call[0]));
    }


    //公告
    function notice(){
        Granular::MODEL('user')->vlogin();
		$call = Granular::MYSQL('notice')->select();
        Granular::IMPORT('notice',array("call"=>$call));
    }	
    # 添加公告
    function noticeAdd(){
        Granular::MODEL('user')->vlogin();
        $query = Granular::MYSQL('category')->select();
        Granular::IMPORT('noticeAdd',array('query'=>$query));
    }
    # 修改公告
    function noticeEdit(){
        Granular::MODEL('user')->vlogin();
        $query = Granular::MYSQL('notice')->select();
        $id = Granular::REQUEST('get', 'id', 'sql');
        $call = Granular::MYSQL('notice')->select("id={$id}");
        Granular::IMPORT('noticeEdit',array('query'=>$query,"call"=>$call));
    }



	
    //友联
    function chain(){
        Granular::MODEL('user')->vlogin();
		$call = Granular::MYSQL('chain')->select();
        Granular::IMPORT('chain',array("call"=>$call));
    }	
    # 添加友联
    function chainAdd(){
        Granular::MODEL('user')->vlogin();
        $query = Granular::MYSQL('category')->select();
        Granular::IMPORT('chainAdd',array('query'=>$query));
    }
    # 修改友联
    function chainEdit(){
        Granular::MODEL('user')->vlogin();
        $query = Granular::MYSQL('chain')->select();
        $id = Granular::REQUEST('get', 'id', 'sql');
        $call = Granular::MYSQL('chain')->select("id={$id}");
        Granular::IMPORT('chainEdit',array('query'=>$query,"call"=>$call));
    }
    
    //库存管理
    function repertory(){
        Granular::MODEL('user')->vlogin();
        $query = Granular::MODEL('ry')->query();
        $call = Granular::MYSQL('shop')->select();
        Granular::IMPORT('repertory',array("query"=>$query,"shop"=>$call));
    }
    # 添加库存
    function ryAdd(){
        Granular::MODEL('user')->vlogin();
        $query = Granular::MYSQL('shop')->select();
        Granular::IMPORT('ryAdd',array('query'=>$query));
    }
    # 导出库存
    function ryExport(){
        Granular::MODEL('user')->vlogin();
        $rx = Granular::MODEL('ry')->export();
        Granular::IMPORT('veExport',array("rx"=>$rx));
    }
    
    //个人资料
    function profile(){
        Granular::MODEL('user')->vlogin();
        $userDb = Granular::MYSQL('user')->select("user_username='{$_SESSION['sid']['username']}'");
        Granular::IMPORT('profile',array("userInfo"=>$userDb[0]));
    }
    //订单管理
    function order(){
        Granular::MODEL('user')->vlogin();
        $query = Granular::MODEL('od')->query();
        Granular::IMPORT('order',array('query'=>$query));
    }
	//------------------------------------通讯配置
    //通讯管理
    function passageway(){
        Granular::MODEL('user')->vlogin();
		$date = Granular::MYSQL('passageway')->select();
        Granular::IMPORT('passageway',array('date'=>$date));
    } 
    // 添加配置
    function passagewayAdd(){
        Granular::MODEL('user')->vlogin();
        $query = Granular::MYSQL('passageway')->select();
        Granular::IMPORT('passagewayAdd',array('query'=>$query));
    }
    // 修改配置
    function passagewayEdit(){
        Granular::MODEL('user')->vlogin();
        $query = Granular::MYSQL('passageway')->select();
        $id = Granular::REQUEST('get', 'id', 'sql');
        $call = Granular::MYSQL('passageway')->select("id={$id}");
        Granular::IMPORT('passagewayEdit',array('query'=>$query,"call"=>$call[0]));
    }	
	//------------------------------------通讯配置结束
}