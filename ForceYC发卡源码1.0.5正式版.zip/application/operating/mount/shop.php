<?php
class shop{
    function add(){
        Granular::MODEL('user')->vlogin();
        Granular::MODEL('sp')->add();
    }
    function delete(){
        Granular::MODEL('user')->vlogin();
        Granular::MODEL('sp')->delete();
    }
    function edit(){
        Granular::MODEL('user')->vlogin();
        Granular::MODEL('sp')->edit();
    }
}