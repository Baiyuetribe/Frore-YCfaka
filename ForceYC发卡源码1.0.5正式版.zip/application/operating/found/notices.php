<?php
class notices{
    //添加公告
    function add(){
        //接受post数据
        $notice_text = Granular::REQUEST('post', 'notice_text' ,'xss');
  
        if (empty($notice_text)) Granular::JSON(-2, '公告内容不能为空');
        
        $call = Granular::MYSQL('notice');
        
        $add = $call->insert(array(
            "notice_text"=>$notice_text
        ));
        
        if ($add){
            Granular::JSON(1, '添加成功');
        }else{
            Granular::JSON(-4, '添加失败');
        }
        
    }
    
    
    //删除
    function delete(){
        $id = Granular::REQUEST('get', 'id', 'sql');
        $mysql = Granular::MYSQL('notice');
        //删除自身
        $delete_cate = $mysql->delete("id={$id}");
        if ($delete_cate){
            Granular::JSON(1, '删除成功');
        }else{
            Granular::JSON(-7, '删除失败');
        }
    }
    //修改公告
    function edit(){
        //接受post数据
       
        $id = Granular::REQUEST('get', 'id', 'sql');
        $notice_text = Granular::REQUEST('post', 'notice_text' ,'xss');
  
        if (empty($notice_text)) Granular::JSON(-2, '公告内容不能为空');
        
        $call = Granular::MYSQL('notice');
        
        $edit = $call->update(array(
            "notice_text"=>$notice_text
        ),"id={$id}");
        
        if ($edit){
            Granular::JSON(1, '修改成功');
        }else{
            Granular::JSON(-4, '修改失败');
        }
        
    }
  
}