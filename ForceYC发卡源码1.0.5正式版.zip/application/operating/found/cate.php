<?php
class cate{
    //添加
    function add(){
         $category_name = Granular::REQUEST('post', 'category_name', 'xss'); 
        
         if (empty($category_name)) Granular::JSON(-2, '分类名称不能为空'); 
        
         $category = Granular::MYSQL('category');
         
         $uniqid = strtoupper(substr(md5(mt_rand(1000000,9999999) . mt_rand(1000,9999)), 0, 10));
        
        $add = $category->insert(array("category_name"=>$category_name,"category_uniqid"=>$uniqid));
        
        if ($add){
            Granular::JSON(1, '添加成功');
        }else{
            Granular::JSON(-3, '添加失败');
        } 
    }
    
    //查询
    function query(){
        $page = array('num'=>Granular::REQUEST('get', 'page','sql'),'all'=>15);
        
        $desc = array('desc'=>'id','by'=>'desc');
        
        $query = Granular::MODEL('query')->column('category',$page,null,$desc);
        
        return $query;
    }
    
    //修改
    function edit(){
        $category_name = Granular::REQUEST('post', 'category_name', 'xss');
        
        if (empty($category_name)) Granular::JSON(-2, '分类名称不能为空');
        
        $id = Granular::REQUEST('get', 'id', 'sql');
        
        $category = Granular::MYSQL('category');
        
        $edit = $category->update(array("category_name"=>$category_name),"id={$id}");
        
        if ($edit){
            Granular::JSON(1, '修改成功');
        }else{
            Granular::JSON(-3, '修改失败');
        }
    }
    
    //删除
    function delete(){
        $id = Granular::REQUEST('get', 'id', 'sql');
        $mysql = Granular::MYSQL('category');
        //删除自身分类
        $delete_cate = $mysql->delete("id={$id}");
        if ($delete_cate){
            Granular::JSON(1, '删除成功');
        }else{
            Granular::JSON(-7, '删除失败');
        }
    }
}