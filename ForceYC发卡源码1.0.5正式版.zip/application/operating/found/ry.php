<?php
class ry{
    //查询
    function query(){
        
        $Where = null;
       
        $page = array('num'=>Granular::REQUEST('get', 'page','sql'),'all'=>15);
        
        $desc = array('desc'=>'id','by'=>'desc');
        
        //状态查询
        $state = Granular::REQUEST('get', 'state','sql');
        if ($state != ''){
            $Where[] = array('type'=>false,'dary'=>'and','cont'=>'=','word'=>array('key'=>'repertory_state','val'=>$state));
        }
        
        //卡密查询
        $card = Granular::REQUEST('get', 'card','sql');
        if ($card != ''){
            $Where[] = array('type'=>true,'dary'=>'and','cont'=>'=','word'=>array('key'=>'repertory_card','val'=>$card));
        }
        
        //联系方式查询
        $contact = Granular::REQUEST('get', 'contact','xss');
        if ($contact != ''){
            $Where[] = array('type'=>true,'dary'=>'and','cont'=>'=','word'=>array('key'=>'repertory_contact','val'=>$contact));
        }
        
        //商品分类查询
        $category = Granular::REQUEST('get', 'cid','xss');
        if ($category != ''){
            $Where[] = array('type'=>false,'dary'=>'and','cont'=>'=','word'=>array('key'=>'repertory_shopid','val'=>$category));
        }
        
        $query = Granular::MODEL('query')->column('repertory',$page,$Where,$desc);
        
        return $query;
    }
    
    //添加
    function add(){
        //接受数据区域（严格分析）
        $repertory_shopid = Granular::REQUEST('post', 'repertory_shopid', 'xss');
        
        $repertory_card = Granular::REQUEST('post', 'repertory_card');
        
        if (empty($repertory_card)) Granular::JSON(-2, '不支持空卡密');
        
        //开始拆分卡密
        $repertory_card = explode(PHP_EOL, trim(trim($repertory_card,PHP_EOL)));

        //初始化数据库，准备入库
        $call = Granular::MYSQL('repertory');
        
        //监控入库成功的卡密
        $camiNum = 0;
        
        //开始循环数组
        for ($i=0;$i<count($repertory_card);$i++){
            $add = $call->insert(array(
                "repertory_shopid"=>$repertory_shopid,
                "repertory_card"=>$repertory_card[$i],
                "repertory_state"=>1,
                "repertory_contact"=>0,
                "repertory_addtime"=>time(),
                "repertory_paytime"=>0
            ));
            if ($add){
                $camiNum = $camiNum+1;
            }
        }
          
        Granular::JSON(1, '添加完成,共入库:' . $camiNum . ' 张卡密');
    }
    
    //导出优惠卷
    function export(){
        //导出类型
        $type = Granular::REQUEST('get', 'type','sql');
        //导出分类
        $cmd = Granular::REQUEST('get', 'cmd', 'sql');
        //初始化数据库
        $call = Granular::MYSQL('repertory');
        
        //缓存变量
        $rx = '';
        
        //如果为商品
        if ($cmd != ''){
            
            $dvr = $call->select("repertory_shopid={$cmd} and repertory_state={$type}");
            foreach ($dvr as $r){
                $rx .= $r['repertory_card'] . PHP_EOL;
            }
            
        }else{
            
            $dvr = $call->select("repertory_state={$type}");
            foreach ($dvr as $r){
                $rx .= $r['repertory_card'] . PHP_EOL;
            }
            
        }
        
        $rx = trim($rx,PHP_EOL);
        
        if (empty($rx)){
            return '当前导出方式没有卡密喔~';
        }else{
            return $rx;
        }
        
    }
}