<?php
class payment{
    //添加配置
    function add(){
        //接受post数据
        
        $passageway_titile = Granular::REQUEST('post', 'passageway_titile' ,'xss');
        
        $passageway_website = Granular::REQUEST('post', 'passageway_website', 'xss');
		
        $passageway_username = Granular::REQUEST('post', 'passageway_username', 'xss');
        
        $passageway_key = Granular::REQUEST('post', 'passageway_key', 'xss');
        
        $call = Granular::MYSQL('passageway');
        
        $add = $call->insert(array(
            "passageway_titile"=>$passageway_titile,
            "passageway_website"=>$passageway_website,
            "passageway_username"=>$passageway_username,
            "passageway_key"=>$passageway_key,
            "passageway_ctime"=>time(),
            "passageway_state"=>2
        ));
        
        if ($add){
            Granular::JSON(1, '添加成功');
        }else{
            Granular::JSON(-4, '添加失败');
        }
    }
     //状态修改
    function state(){
        $id = Granular::REQUEST('get', 'id', 'sql');
        $state = Granular::REQUEST('get', 'state', 'sql');
        $mysql = Granular::MYSQL('passageway');
       
	   if ($state == "1"){
			$stateall = "2";
		}else if ($state == "2"){
			$stateall = "1";
		}
	   $call = Granular::MYSQL('passageway');
	   
	   	$edit = $call->update(array(
       "passageway_state"=>2,
        ));
		
	   $edit = $call->update(array(
       "passageway_state"=>$stateall,
        ),"id={$id}");
	 if ($edit){
            echo '修改成功';
        }else{
            echo '修改失败';
        }
    }   
    //删除
    function delete(){
        $id = Granular::REQUEST('get', 'id', 'sql');
        $mysql = Granular::MYSQL('passageway');
        //删除自身分类
        $delete_cate = $mysql->delete("id={$id}");
        if ($delete_cate){
            Granular::JSON(1, '删除成功');
        }else{
            Granular::JSON(-7, '删除失败');
        }
    }
    //修改配置
    function edit(){
        //接受post数据
        $id = Granular::REQUEST('get', 'id', 'sql');
		
        $passageway_titile = Granular::REQUEST('post', 'passageway_titile' ,'xss');
        
        $passageway_website = Granular::REQUEST('post', 'passageway_website', 'xss');
		
        $passageway_username = Granular::REQUEST('post', 'passageway_username', 'xss');
        
        $passageway_key = Granular::REQUEST('post', 'passageway_key', 'xss');
        
        $call = Granular::MYSQL('passageway');
        
        $edit = $call->update(array(
            "passageway_titile"=>$passageway_titile,
            "passageway_website"=>$passageway_website,
            "passageway_username"=>$passageway_username,
            "passageway_key"=>$passageway_key
        ),"id={$id}");
        
        if ($edit){
            Granular::JSON(1, '修改成功');
        }else{
            Granular::JSON(-4, '修改失败');
        }
        
    }
  
}