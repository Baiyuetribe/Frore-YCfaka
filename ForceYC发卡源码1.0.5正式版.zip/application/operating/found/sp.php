<?php
class sp{
    //添加商品
    function add(){
        //接受post数据
        
        $shop_name = Granular::REQUEST('post', 'shop_name' ,'xss');
        
        $shop_price = Granular::REQUEST('post', 'shop_price', 'xss');
        $shop_cost = Granular::REQUEST('post', 'shop_cost', 'xss');
        
        $shop_rank = Granular::REQUEST('post', 'shop_rank', 'xss');
        
        $shop_warning = Granular::REQUEST('post', 'shop_warning', 'xss');
        
        $shop_cateid = Granular::REQUEST('post', 'shop_cateid', 'xss');
        $shop_text = Granular::REQUEST('post', 'shop_text', 'xss');
        
        
        $uniqid = strtoupper(substr(md5(mt_rand(1000000,9999999) . mt_rand(1000,9999)), 0, 10));
        
        if (empty($shop_name)) Granular::JSON(-2, '商品名称不能为空');
        
        if ($shop_price <= 0) Granular::JSON(-3, '商品单价不能为0或者小于0');
        
        $call = Granular::MYSQL('shop');
        
        $add = $call->insert(array(
            "shop_name"=>$shop_name,
            "shop_cost"=>$shop_cost,
            "shop_price"=>$shop_price,
            "shop_rank"=>$shop_rank,
            "shop_warning"=>$shop_warning,
            "shop_cateid"=>$shop_cateid,
            "shop_uniqid"=>$uniqid,
            "shop_text"=>$shop_text
        ));
        
        if ($add){
            Granular::JSON(1, '添加成功');
        }else{
            Granular::JSON(-4, '添加失败');
        }
        
    }
    
    //查询
    function query(){
        $page = array('num'=>Granular::REQUEST('get', 'page','sql'),'all'=>15);
        
        $desc = array('desc'=>'id','by'=>'desc');
        
        $query = Granular::MODEL('query')->column('shop',$page,null,$desc);
        
        return $query;
    }
    
    //删除
    function delete(){
        $id = Granular::REQUEST('get', 'id', 'sql');
        $mysql = Granular::MYSQL('shop');
        //删除自身分类
        $delete_cate = $mysql->delete("id={$id}");
        if ($delete_cate){
            Granular::JSON(1, '删除成功');
        }else{
            Granular::JSON(-7, '删除失败');
        }
    }
    //修改商品
    function edit(){
        //接受post数据
        
        $shop_name = Granular::REQUEST('post', 'shop_name' ,'xss');
        
        $shop_price = Granular::REQUEST('post', 'shop_price', 'xss');
        $shop_cost = Granular::REQUEST('post', 'shop_cost', 'xss');
        
        $shop_rank = Granular::REQUEST('post', 'shop_rank', 'xss');
        
        $shop_warning = Granular::REQUEST('post', 'shop_warning', 'xss');
        
        $shop_cateid = Granular::REQUEST('post', 'shop_cateid', 'xss');
        $shop_text = Granular::REQUEST('post', 'shop_text', 'xss');
        
        $id = Granular::REQUEST('get', 'id', 'sql');
        
        if (empty($shop_name)) Granular::JSON(-2, '商品名称不能为空');
        
        if ($shop_price <= 0) Granular::JSON(-3, '商品单价不能小于1元');
        
        $call = Granular::MYSQL('shop');
        
        $edit = $call->update(array(
            "shop_name"=>$shop_name,
            "shop_cost"=>$shop_cost,
            "shop_price"=>$shop_price,
            "shop_rank"=>$shop_rank,
            "shop_warning"=>$shop_warning,
            "shop_cateid"=>$shop_cateid,
            "shop_text"=>$shop_text
        ),"id={$id}");
        
        if ($edit){
            Granular::JSON(1, '修改成功');
        }else{
            Granular::JSON(-4, '修改失败');
        }
        
    }
  
}