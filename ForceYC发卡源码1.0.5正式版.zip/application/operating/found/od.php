<?php
class od{
    function query() {
        $Where  = null;
        
        $page = array('num'=>Granular::REQUEST('get', 'page','sql'),'all'=>15);
        
        $desc = array('desc'=>'id','by'=>'desc');
        
        //订单状态分类查询
        $category = Granular::REQUEST('get', 'state','xss');
        if ($category != ''){
            $Where[] = array('type'=>false,'dary'=>'and','cont'=>'=','word'=>array('key'=>'order_state','val'=>$category));
        }
        
        //订单支付方式查询
        $pay = Granular::REQUEST('get', 'pay','xss');
        if ($pay != ''){
            $Where[] = array('type'=>false,'dary'=>'and','cont'=>'=','word'=>array('key'=>'order_payx','val'=>$pay));
        }
        
        //订单号查询
        $card = Granular::REQUEST('get', 'card','sql');
        if ($card != ''){
            $Where[] = array('type'=>true,'dary'=>'and','cont'=>'=','word'=>array('key'=>'order_number','val'=>$card));
        }
        
        //联系方式查询
        $contact = Granular::REQUEST('get', 'contact','xss');
        if ($contact != ''){
            $Where[] = array('type'=>true,'dary'=>'and','cont'=>'=','word'=>array('key'=>'order_contact','val'=>$contact));
        }
        
        $query = Granular::MODEL('query')->column('order',$page,$Where,$desc);
        
        return $query;
    }
}