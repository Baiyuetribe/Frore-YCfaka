<?php
class chains{
    //添加友链
    function add(){
        //接受post数据
        $chain_name = Granular::REQUEST('post', 'chain_name' ,'xss');
        
        $chain_http = Granular::REQUEST('post', 'chain_http', 'xss');
  
        if (empty($chain_name)) Granular::JSON(-2, '友链名称不能为空');
        if (empty($chain_http)) Granular::JSON(-2, '友链地址不能为空');
        
        $call = Granular::MYSQL('chain');
        
        $add = $call->insert(array(
            "chain_name"=>$chain_name,
            "chain_http"=>$chain_http
        ));
        
        if ($add){
            Granular::JSON(1, '添加成功');
        }else{
            Granular::JSON(-4, '添加失败');
        }
        
    }
    
    
    //删除
    function delete(){
        $id = Granular::REQUEST('get', 'id', 'sql');
        $mysql = Granular::MYSQL('chain');
        //删除自身
        $delete_cate = $mysql->delete("id={$id}");
        if ($delete_cate){
            Granular::JSON(1, '删除成功');
        }else{
            Granular::JSON(-7, '删除失败');
        }
    }
    //修改友链
    function edit(){
        //接受post数据
        $chain_name = Granular::REQUEST('post', 'chain_name' ,'xss');
        
        $chain_http = Granular::REQUEST('post', 'chain_http', 'xss');
        
        $id = Granular::REQUEST('get', 'id', 'sql');
        
        if (empty($chain_name)) Granular::JSON(-2, '友链名称不能为空');
        if (empty($chain_http)) Granular::JSON(-2, '友链地址不能为空');
        
        $call = Granular::MYSQL('chain');
        
        $edit = $call->update(array(
            "chain_name"=>$chain_name,
            "chain_http"=>$chain_http
        ),"id={$id}");
        
        if ($edit){
            Granular::JSON(1, '修改成功');
        }else{
            Granular::JSON(-4, '修改失败');
        }
        
    }
  
}