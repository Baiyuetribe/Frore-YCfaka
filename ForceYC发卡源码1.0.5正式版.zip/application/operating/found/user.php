<?php
# 用户自动化模型
class user{
    //登录
    function login(){
        
        //检测账号是否登录
        if (is_array($_SESSION['sid'])) {
            if (count($_SESSION['sid']) == 2){
                Granular::JUMP(__URL__ . '/index/home', 1, '请稍后,自动登录中..');
            }
        }
        
        $mysql = Granular::MYSQL('user');
        //接受账号
        $username = Granular::REQUEST('post', 'username', 'xss');
        //接受密码
        $password = Granular::REQUEST('post', 'password', 'xss');
        //用户处理
        $userQuery = $mysql->select("user_username='{$username}'");
        
        if (!is_array($userQuery[0])) Granular::JSON(-1, '账号不存在');
        
        //密码处理
        $pwd = md5($password . $userQuery[0]['user_token']);
        
        if ($pwd != $userQuery[0]['user_password']) Granular::JSON(-2, '密码错误');
        
        //存取用户信息
        $_SESSION['sid'] = array("username"=>$userQuery[0]['user_username'] , 'token'=>$userQuery[0]['user_token']);
        
        Granular::JSON(1, '登录成功');

    }
    
    //修改资料
    function edit(){
        //验证是否登录
        $this->vlogin();
        //接受数据区
        $user_username = Granular::REQUEST('post', 'user_username','xss');
        if (empty($user_username)) Granular::JUMP(__URL__ . '/index/profile', 1, '用户名不能为空');
        
        $user_password = Granular::REQUEST('post', 'user_password','xss');
        $user_qq = Granular::REQUEST('post', 'user_qq','xss');
        $user_title = Granular::REQUEST('post', 'user_title','xss');
        $user_keyword = Granular::REQUEST('post', 'user_keyword','xss');
        $user_description = Granular::REQUEST('post', 'user_description','xss');
        //上传图片
        $upload = Granular::INTERFACED('upload')->run($_FILES['user_logo'],__ROOT__ . '/upload/image/',array("png",'jpg','jpeg'), 10000);
        
        $mysql = Granular::MYSQL('user');
        //查询数据库
        $call = $mysql->select("user_username='{$_SESSION['sid']['username']}'");
        
        if (!is_array($call[0])){
            Granular::JUMP(__URL__ . '/index/profile', 1, '用户配置出错,请重新登录再尝试!');
        }
        
        if (!empty($user_password)){
            $token = substr(md5(mt_rand(mt_rand(10000,99999),mt_rand(1000000,999999999))), 0,6);
            $user_password = md5($user_password . $token);
        }else{
            $token = $call[0]['user_token'];
            $user_password = $call[0]['user_password'];
        }
        
        if (is_array($upload)){
            $user_logo = 'upload/image/' . $upload['ok'];
        }else{
            $user_logo = $call[0]['user_logo'];
        }

        //修改密码 && 修改logo
   
        $f =  $mysql->update(array(
                "user_username"=>$user_username,
                "user_password"=>$user_password,
                "user_token"=>$token,
                "user_qq"=>$user_qq,
                "user_title"=>$user_title,
                "user_keyword"=>$user_keyword,
                "user_description"=>$user_description,
                "user_logo"=>$user_logo,
            ), "user_username='{$_SESSION['sid']['username']}'");
    
            Granular::JUMP(__URL__ . '/index/profile', 1, '修改成功!');

        
    }
    
    //验证登陆
    function vlogin(){
        //检测账号是否登录
        if (is_array($_SESSION['sid'])) {
            if (count($_SESSION['sid']) != 2){
                Granular::JUMP(__URL__ . '/index/login', 1, '用户验证失败');
            }
        }else {
            Granular::JUMP(__URL__ . '/index/login', 1, '请登录后操作!');
        }
    }

}
?>