	<form id="wint" style="margin: 10px;margin-top:20px;">
		<div class="form-group">
			<label class="active">选择商品：</label>
			<select name="repertory_shopid">
			<?php foreach ($query as $shop){?>
 			 <option value ="<?php echo $shop['id'];?>"><?php echo $shop['shop_name'];?></option>
 			<?php }?>
		</select>
		</div>

		<div class="form-group">
			<label class="active">卡密信息：</label>
			<textarea rows="19" cols="20" class="form-control" placeholder="卡密，一行一条信息" name="repertory_card"></textarea>
		</div>
		
		
	</form>
	