<!DOCTYPE HTML>
<html lang="zh-cn">
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>订单管理</title>
	<link href="<?php echo __STATIC__;?>/plugins/bootstrap-3.3.0/css/bootstrap.min.css" rel="stylesheet"/>
	<link href="<?php echo __STATIC__;?>/plugins/material-design-iconic-font-2.2.0/css/material-design-iconic-font.min.css" rel="stylesheet"/>
	<link href="<?php echo __STATIC__;?>/plugins/bootstrap-table-1.11.0/bootstrap-table.min.css" rel="stylesheet"/>
	<link href="<?php echo __STATIC__;?>/plugins/waves-0.7.5/waves.min.css" rel="stylesheet"/>
	<link href="<?php echo __STATIC__;?>/plugins/jquery-confirm/jquery-confirm.min.css" rel="stylesheet"/>
	<script src="<?php echo __STATIC__;?>/js/jquery-latest.js"></script>
	<script src="<?php echo __STATIC__;?>/js/layer/3.0/layer.js"></script>
	<style type="text/css">
body, html {height: 100%; position: relative; font-family: 'Microsoft yahei'; font-size: 13px; font-weight: 400;}
img {vertical-align: middle;}
a, a:hover, a:active, a:focus {text-decoration: none; -webkit-user-drag: none; outline: none; color: #000;}
a i{font-size: 13px;}

#main{padding: 10px 20px;}

/* 数据表格 */
body{font-size: 12px;}
.table i{font-size: 12px; color: #000;}
.bootstrap-table .table>thead>tr>th{border-bottom: none;}
.bootstrap-table .table:not(.table-condensed), .bootstrap-table .table:not(.table-condensed)>tbody>tr>td, .bootstrap-table .table:not(.table-condensed)>tbody>tr>th, .bootstrap-table .table:not(.table-condensed)>tfoot>tr>td, .bootstrap-table .table:not(.table-condensed)>tfoot>tr>th, .bootstrap-table .table:not(.table-condensed)>thead>tr>td{padding: 12px 8px;}
/* 分页 */
.pagination>.active>a, .pagination>.active>span, .pagination>.active>a:hover, .pagination>.active>span:hover, .pagination>.active>a:focus, .pagination>.active>span:focus{background: #f5f5f5; color: #000; border-color: #7d7d7d;}
.pagination>li>a, .pagination>li>span{color: #000;}.dropdown-menu>.active>a, .dropdown-menu>.active>a:hover, .dropdown-menu>.active>a:focus{background-color: #999;}
/* bootstrap */
.jconfirm .jconfirm-box .jconfirm-buttons button{-webkit-border-radius: 0; border-radius: 0;}
.btn:active{-webkit-box-shadow: none; box-shadow: none;}
    .editbt{
	   color:green;
    }
    .deletebt{
	   color:red;
    }
    </style>
</head>
<body>
<div id="main">
	<div id="toolbar">
		<select name="" onchange="javascript:location.href=this.value;">
			<option value="<?php echo __URL__;?>/index/order" <?php echo $_GET['cid']=='' ? 'selected' : '' ;?> >所有订单</option>
			<option value="<?php echo __URL__;?>/index/order/state/1" <?php echo $_GET['state']==='1' ? 'selected' : '' ;?> >未支付</option>
			<option value="<?php echo __URL__;?>/index/order/state/2" <?php echo $_GET['state']==='2' ? 'selected' : '' ;?> >已支付</option>
			<option value="<?php echo __URL__;?>/index/order/state/3" <?php echo $_GET['state']==='3' ? 'selected' : '' ;?> >已超时</option>
		</select>
		
		<select name="" onchange="javascript:location.href=this.value;">
			<option value="<?php echo __URL__;?>/index/order" <?php echo $_GET['pay']=='' ? 'selected' : '' ;?> >所有订单</option>
		</select>
		
		<input type="text" value="" id="keyword">
		<select id="typec">
 		<option value ="2">订单号</option>
 		<option value ="3">联系方式</option>
		</select>
		<a class="waves-effect waves-button" href="javascript:;" onclick="queryAction()">查询</a>
		<a class="waves-effect waves-button" href="javascript:;" onclick="deleteAction()" style="display:none;" id="delbtn">✖  删除选中</a>
		
	</div>
	  <?php if ($query['info']['page'] != 0){?>
	<table class="table">
  <caption>那个人，你在哪，你知道吗，我现在很累。</caption>
  <thead>
    <tr>
      <th><input type="checkbox" id="all"></th>
      <th>订单号</th>
      <th>商品</th>
      <th>订单信息</th>
      <th>联系方式</th>
      <th>创建时间</th>
      <th>支付时间</th>
      <th>支付方式</th>
      <th>总金额</th>
      <th>订单状态</th>
    </tr>
  </thead>

  <tbody id="list">
  <?php foreach ($query['data'] as $qr){?>
    <tr>
      <td><input type="checkbox" name="ckbox" value="<?php echo $qr['id'];?>"></td>
      <td><?php echo $qr['order_number'];?></td>
      <td><?php $call = Granular::MYSQL('shop')->select("id={$qr['order_shopid']}");echo $call[0]['shop_name'];?></td>
      <td style="width: 20%;"><?php echo $qr['order_info'];?></td>
      <td><?php echo $qr['order_contact'];?></td>
      <td><?php echo date("Y/m/d H:i:s", $qr['order_creatime']);?></td>
      <td><?php echo $qr['order_paytime'] != 0 ? date("Y/m/d H:i:s", $qr['order_paytime']) : '无';?></td>
      <td><?php if ($qr['order_payx']==1){echo '支付宝';} if ($qr['order_payx']==2){echo '微信';} if ($qr['order_payx']==3){echo 'QQ钱包';}?></td>
      <td><?php echo $qr['order_moeny'];?></td>
	  <td><?php if ($qr['order_state']==1){echo '<span style="color:red;">未支付</span>';} if ($qr['order_state']==2){echo '<span style="color:green;">已支付</span>';} if ($qr['order_state']==3){echo '<span style="color:gray;">已超时</span>';}?></td>

    </tr>
  <?php }?>
  </tbody>
  

</table>

<?php }else {echo '当前还没有订单喔~';}?>

<ul class="pagination" style="margin-top: 0px;">
    <?php Granular::MODEL('page')->auto($query['info']['page'],$query['info']['current'],10);?>
</ul>


</div>


<script src="<?php echo __STATIC__;?>/plugins/jquery.1.12.4.min.js"></script>
<script src="<?php echo __STATIC__;?>/plugins/bootstrap-3.3.0/js/bootstrap.min.js"></script>
<script src="<?php echo __STATIC__;?>/plugins/bootstrap-table-1.11.0/bootstrap-table.min.js"></script>
<script src="<?php echo __STATIC__;?>/plugins/bootstrap-table-1.11.0/locale/bootstrap-table-zh-CN.min.js"></script>
<script src="<?php echo __STATIC__;?>/plugins/waves-0.7.5/waves.min.js"></script>
<script src="<?php echo __STATIC__;?>/plugins/jquery-confirm/jquery-confirm.min.js"></script>
<script src="<?php echo __STATIC__;?>/js/common.js"></script>

<script>

//选择框操作
$("#all").click(function(){   
    if(this.checked){   
        $("#list :checkbox").prop("checked", true);  
        $("#delbtn").show();
    }else{   
	$("#list :checkbox").prop("checked", false);
	$("#delbtn").hide();
    }   
});

$("input[name='ckbox']").click(function(){
	
	var chk_value =[]; 
	
	$('input[name="ckbox"]:checked').each(function(){ 
	chk_value.push($(this).val()); 
	}); 
	
	if(chk_value.length != 0){
		$("#delbtn").show();
	}else{
		$("#delbtn").hide();
		}
	
});


//删除
function deleteAction() {
	
	var chk_value =[]; 
	
	$('input[name="ckbox"]:checked').each(function(){ 
	chk_value.push($(this).val()); 
	}); 
	
	if(chk_value.length != 0){
		$.get("<?php echo __URL__;?>/payservice/orderDelete/id/"+chk_value,function(data,status){
		    alert(data.msg);
		    location.href='';
		  });
	}

}

//删除超出二十四小时未支付的订单
function delete24() {
		$.get("<?php echo __URL__;?>/payservice/orderDelete24/"+ function(data,status){
		    alert(data.msg);
		    location.href='';
		  });
	

}
//查询
function queryAction(){
  var type = $('#typec').val();
  var keyword = $('#keyword').val();

  if(type == 2){
	location.href='<?php echo __URL__;?>/index/order/card/'+keyword;
	  }
  if(type == 3){
	location.href='<?php echo __URL__;?>/index/order/contact/'+keyword;
	  }
}



</script>

<script src="<?php echo __STATIC__;?>/js/llqrcode.js" type="text/javascript" charset="utf-8"></script>
<script src="<?php echo __STATIC__;?>/js/analyticCode.js" type="text/javascript" charset="utf-8"></script>
</body>
</html>