    <form id="wint" style="margin: 10px;margin-top:20px;">
		<div class="form-group">
			<label class="active">公告内容</label>
			<input type="text" name="notice_text" class="form-control meetsdk" value="<?php echo $call[0]['notice_text'];?>">
		</div>
	</form>
	