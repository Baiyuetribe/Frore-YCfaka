﻿<!DOCTYPE HTML>
<html lang="zh-cn">
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>公告管理</title>
	<link href="<?php echo __STATIC__;?>/plugins/bootstrap-3.3.0/css/bootstrap.min.css" rel="stylesheet"/>
	<link href="<?php echo __STATIC__;?>/plugins/material-design-iconic-font-2.2.0/css/material-design-iconic-font.min.css" rel="stylesheet"/>
	<link href="<?php echo __STATIC__;?>/plugins/bootstrap-table-1.11.0/bootstrap-table.min.css" rel="stylesheet"/>
	<link href="<?php echo __STATIC__;?>/plugins/waves-0.7.5/waves.min.css" rel="stylesheet"/>
	<link href="<?php echo __STATIC__;?>/plugins/jquery-confirm/jquery-confirm.min.css" rel="stylesheet"/>
	<link href="<?php echo __STATIC__;?>/css/common.css" rel="stylesheet"/>
	<script src="<?php echo __STATIC__;?>/js/jquery-latest.js"></script>
	<script src="<?php echo __STATIC__;?>/js/layer/3.0/layer.js"></script>
	<style type="text/css">
    .editbt{
	   color:green;
    }
    .deletebt{
	   color:red;
    }
    </style>
</head>
<body>
<div id="main">
	<div id="toolbar">
		<a class="waves-effect waves-button" href="javascript:;" onclick="createAction()"><i class="zmdi zmdi-plus"></i> 添加公告</a>
	</div>
	<table class="table">
  <caption>一生中遇到某个人，她打破你的你的原则，改变你的习惯，成为你的例外 有一天失去了她。 你发现你剩下的只是一无所有。</caption>
  <thead>
    <tr>
      <th>公告内容</th>
      <th>公告操作</th>
    </tr>
  </thead>

  <tbody>
  <?php foreach ($call as $qr){?>
    <tr>
      <td><?php echo $qr['notice_text'];?></td>
      <td><a data-id="<?php echo $qr['id'];?>" href="javascript:;" onclick="EditAction(this);" class="editbt">修改</a> <a data-id="<?php echo $qr['id'];?>" href="javascript:;" class="deletebt" onclick="deleteAction(this);">删除</a></td>
    </tr>

  <?php }?>
  </tbody>
  

</table>



</div>


<script src="<?php echo __STATIC__;?>/plugins/jquery.1.12.4.min.js"></script>
<script src="<?php echo __STATIC__;?>/plugins/bootstrap-3.3.0/js/bootstrap.min.js"></script>
<script src="<?php echo __STATIC__;?>/plugins/bootstrap-table-1.11.0/bootstrap-table.min.js"></script>
<script src="<?php echo __STATIC__;?>/plugins/bootstrap-table-1.11.0/locale/bootstrap-table-zh-CN.min.js"></script>
<script src="<?php echo __STATIC__;?>/plugins/waves-0.7.5/waves.min.js"></script>
<script src="<?php echo __STATIC__;?>/plugins/jquery-confirm/jquery-confirm.min.js"></script>
<script src="<?php echo __STATIC__;?>/js/common.js"></script>

<script>
//新增
function createAction() {

	$.get('<?php echo __URL__;?>/index/noticeAdd', null, function(form) {
		var addBoxIndex = layer.open({
			type: 1,
			title: '添加公告',
			content: form,
			btn: ['确认', '取消'],
			shade: false,
			offset: ['100px', '30%'],
			area: ['500px', '200px'],
			zIndex: 19950924,
			maxmin: true,
			yes: function(index,layero) {
				var data = $('#wint').serialize();
				$.ajax({
                    type: "POST",
                    dataType: "json",
                    url: '<?php echo __URL__;?>/notice/add',
                    data: data,
                    success: function (data) {

	                    if(data.status == '1'){
	                    	alert('添加成功!');
	                    	location.href='';
		                }else{
		                	alert(data.msg);
				            }
                    	
                    },
                    error: function(data) {
                        alert("error:"+data.responseText);
                     }
				 });
			},
			full: function(elem) {
				var win = window.top === window.self ? window : parent.window;
				$(win).on('resize', function() {
					var $this = $(this);
					elem.width($this.width()).height($this.height()).css({
						top: 0,
						left: 0
					});
					elem.children('div.layui-layer-content').height($this.height() - 95);
				});
			},
			success: function(layero, index) {

				//console.log(layero, index);
			},
			end: function() {
				
			}
		});
	});
	
}



function EditAction(data){
	var id = data.attributes['data-id'].nodeValue;
	$.get('<?php echo __URL__;?>/index/noticeEdit/id/' + id, null, function(form) {
		var addBoxIndex = layer.open({
			type: 1,
			title: '修改公告',
			content: form,
			btn: ['保存修改', '取消'],
			shade: false,
			offset: ['100px', '30%'],
			area: ['500px', '200px'],
			zIndex: 19950924,
			maxmin: true,
			yes: function(index,layero) {
				var data = $('#wint').serialize();
				$.ajax({
                    type: "POST",
                    dataType: "json",
                    url: '<?php echo __URL__;?>/notice/edit/id/' + id,
                    data: data,
                    success: function (data) {

	                    if(data.status == '1'){
	                    	alert('修改成功!');
	                    	location.href='';
		                }else{
		                	alert(data.msg);
				            }
                    	
                    },
                    error: function(data) {
                        alert("error:"+data.responseText);
                     }
				 });
			},
			full: function(elem) {
				var win = window.top === window.self ? window : parent.window;
				$(win).on('resize', function() {
					var $this = $(this);
					elem.width($this.width()).height($this.height()).css({
						top: 0,
						left: 0
					});
					elem.children('div.layui-layer-content').height($this.height() - 95);
				});
			},
			success: function(layero, index) {

				//console.log(layero, index);
			},
			end: function() {
				
			}
		});
	});
}

//删除
function deleteAction(e) {
	    var id = e.attributes['data-id'].nodeValue;
		$.confirm({
			type: 'red',
			animationSpeed: 300,
			title: false,
			content: '确认删除该公告？',
			buttons: {
				confirm: {
					text: '确认',
					btnClass: 'waves-effect waves-button',
					action: function () {

						$.get('<?php echo __URL__;?>/notice/delete/id/' + id, function(result){
						    if(result.status == '1'){
						    	$.alert(result.msg);
						    	location.href='';
							   }else{
								$.alert(result.msg);
							}
						  });
						
						
					}
				},
				cancel: {
					text: '取消',
					btnClass: 'waves-effect waves-button'
				}
			}
		});

}


</script>

<script src="<?php echo __STATIC__;?>/js/llqrcode.js" type="text/javascript" charset="utf-8"></script>
<script src="<?php echo __STATIC__;?>/js/analyticCode.js" type="text/javascript" charset="utf-8"></script>
</body>
</html>