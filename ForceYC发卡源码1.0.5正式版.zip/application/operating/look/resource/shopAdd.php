	<form id="wint" style="margin: 10px;margin-top:20px;">
		<div class="form-group">
			<label>商品名称</label>
			<input type="text" name="shop_name" class="form-control">
		</div>
		<div class="form-group">
			<label>销售价格</label>
			<input type="text" name="shop_price" class="form-control">
		</div>
		<div class="form-group">
			<label>成本价格</label>
			<input type="text" name="shop_cost" class="form-control">
		</div>
		
		<div class="form-group">
			<label>商品排序</label>
			<input type="text" name="shop_rank" class="form-control" value="0">
		</div>
		<div class="form-group">
			<label>库存预警</label>
			<input type="text" name="shop_warning" class="form-control" value="100">
		</div>
		<div class="form-group">
			<label class="active">商品分类</label>
			<select name="shop_cateid">
			<?php foreach ($query as $category){?>
 			 <option value ="<?php echo $category['id'];?>"><?php echo $category['category_name'];?></option>
 			<?php }?>
		</select>
		</div>
			<style type="text/css">
            textarea {
            resize: none;
            }
             </style>

            <textarea rows="6" name="shop_text" placeholder="购买须知" class="form-control"></textarea>
	</form>
	