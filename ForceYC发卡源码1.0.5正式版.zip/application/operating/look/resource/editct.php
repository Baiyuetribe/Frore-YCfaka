

	<form id="wint" style="margin: 10px;margin-top:20px;">
		<div class="form-group">
			<label class="active">分类名称</label>
			<input type="text" name="category_name" class="form-control meetsdk" value="<?php echo $qrd['category_name'];?>">
		</div>
	</form>
	