    <form id="wint" style="margin: 10px;margin-top:20px;">
		<div class="form-group">
			<label class="active">网站名称</label>
			<input type="text" name="chain_name" class="form-control meetsdk">
		</div>
		<div class="form-group">
			<label class="active">网站链接</label>
			<input type="text" name="chain_http" class="form-control meetsdk">
		</div>
	</form>
	