<link href="<?php echo __STATIC__;?>/plugins/bootstrap-3.3.0/css/bootstrap.min.css" rel="stylesheet" />
<link href="<?php echo __STATIC__;?>/css/admin.css" rel="stylesheet" />

<style>
.inputs {
   
	margin-top:10px;
}
</style>

<div style="margin-top: 20px; margin-left: 20px;">

	<form class="form-inline" action="<?php echo __URL__;?>/payservice/edit" method="post" enctype="multipart/form-data">
		<div class="form-group inputs" style="display: block;">
			<div class="input-group">
				<div class="input-group-addon">用户名</div>
				<input type="text" class="form-control" placeholder="用户名" name="user_username" value="<?php echo $userInfo['user_username'];?>">
				<div class="input-group-addon">用户名是作为登录后台的重要凭证</div>
			</div>
		</div>
		
		<div class="form-group inputs" style="display: block;">
			<div class="input-group">
				<div class="input-group-addon">密码</div>
				<input type="password" class="form-control" placeholder="密码" name="user_password" value="">
				<div class="input-group-addon">不修改请留空即可</div>
			</div>
		</div>
		
		<div class="form-group inputs" style="display: block;">
			<div class="input-group">
				<div class="input-group-addon">Q Q</div>
				<input type="text" class="form-control" placeholder="QQ" name="user_qq" value="<?php echo $userInfo['user_qq'];?>">
				<div class="input-group-addon">QQ号码,作用于客户的联系方式</div>
			</div>
		</div>
		
		<div class="form-group inputs" style="display: block;">
			<div class="input-group">
				<div class="input-group-addon">网站名称</div>
				<input type="text" class="form-control" placeholder="网站名称" name="user_title" value="<?php echo $userInfo['user_title'];?>">
				<div class="input-group-addon">网站名称,用于显示在浏览器标题部位</div>
			</div>
		</div>
		
		<div class="form-group inputs" style="display: block;">
			<div class="input-group">
				<div class="input-group-addon">网站关键词</div>
				<input type="text" class="form-control" placeholder="网站关键词" name="user_keyword" value="<?php echo $userInfo['user_keyword'];?>">
				<div class="input-group-addon">用于搜索引擎搜索关键词排名等</div>
			</div>
		</div>
		
		<div class="form-group inputs" style="display: block;">
			<div class="input-group">
				<div class="input-group-addon">网站简介</div>
				<input type="text" class="form-control" placeholder="网站简介" name="user_description" value="<?php echo $userInfo['user_description'];?>">
				<div class="input-group-addon">用于百度SEO搜索优化,排名等</div>
			</div>
		</div>
		
		<div class="form-group inputs" style="display: block;">
			<div class="input-group">
				<div class="input-group-addon">ICON</div>
				<input type="file" class="form-control" name="user_logo">
				<div class="input-group-addon">ICON用于网站图标显示</div>
			</div>
		</div>	
		
		<div class="form-group inputs" style="display: block;">
			<button type="submit" class="btn btn-success">保存修改(Save)</button>
		</div>
		

	</form>

</div>

<script>

</script>
<script src="<?php echo __STATIC__;?>/plugins/jquery.1.12.4.min.js"></script>
<script src="<?php echo __STATIC__;?>/js/llqrcode.js" type="text/javascript" charset="utf-8"></script>
<script src="<?php echo __STATIC__;?>/js/analyticCode.js" type="text/javascript" charset="utf-8"></script>