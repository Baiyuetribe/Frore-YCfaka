	<form id="wint" style="margin: 10px;margin-top:20px;">
		<div class="form-group">
			<label>网站名称</label>
			<input type="text" name="passageway_titile" class="form-control">
		</div>
		<div class="form-group">
			<label>通讯用户</label>
			<input type="text" name="passageway_username" class="form-control">
		</div>
		<div class="form-group">
			<label>通讯KEY</label>
			<input type="text" name="passageway_key" class="form-control">
		</div>
		
		<div class="form-group">
			<label>通讯网址</label>
			<input type="text" name="passageway_website" class="form-control">
		</div>
	</form>
	