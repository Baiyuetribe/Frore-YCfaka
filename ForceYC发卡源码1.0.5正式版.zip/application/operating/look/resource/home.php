<!DOCTYPE HTML>
<html lang="zh-cn">
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>YCPAY - 你的支付小助手!</title>
    <link rel="icon" href="<?php echo str_replace('admin.php', '', __URL__);?>/favicon.ico"/>
	<link href="<?php echo __STATIC__;?>/plugins/fullPage/jquery.fullPage.css" rel="stylesheet"/>
	<link href="<?php echo __STATIC__;?>/plugins/bootstrap-3.3.0/css/bootstrap.min.css" rel="stylesheet"/>
	<link href="<?php echo __STATIC__;?>/plugins/material-design-iconic-font-2.2.0/css/material-design-iconic-font.min.css" rel="stylesheet"/>
	<link href="<?php echo __STATIC__;?>/plugins/waves-0.7.5/waves.min.css" rel="stylesheet"/>
	<link href="<?php echo __STATIC__;?>/plugins/malihu-custom-scrollbar-plugin/jquery.mCustomScrollbar.min.css" rel="stylesheet"/>
	<link href="<?php echo __STATIC__;?>/css/admin.css" rel="stylesheet"/>
	<style>
	/** skins **/
	#zheng-upms-server #header {background: #29A176;}
	#zheng-upms-server .content_tab{background: #29A176;}
	#zheng-upms-server .s-profile>a{background: url(<?php echo __STATIC__;?>/images/zheng-upms.png) left top no-repeat;}
	
	#zheng-cms-admin #header {background: #455EC5;}
	#zheng-cms-admin .content_tab{background: #455EC5;}
	#zheng-cms-admin .s-profile>a{background: url(<?php echo __STATIC__;?>/images/zheng-cms.png) left top no-repeat;}
	
	#zheng-pay-admin #header {background: #F06292;}
	#zheng-pay-admin .content_tab{background: #F06292;}
	#zheng-pay-admin .s-profile>a{background: url(<?php echo __STATIC__;?>/images/zheng-pay.png) left top no-repeat;}
	
	#zheng-ucenter-home #header {background: #6539B4;}
	#zheng-ucenter-home .content_tab{background: #6539B4;}
	#zheng-ucenter-home .s-profile>a{background: url(<?php echo __STATIC__;?>/images/zheng-ucenter.png) left top no-repeat;}
	
	#zheng-oss-web #header {background: #0B8DE5;}
	#zheng-oss-web .content_tab{background: #0B8DE5;}
	#zheng-oss-web .s-profile>a{background: url(<?php echo __STATIC__;?>/images/zheng-oss.png) left top no-repeat;}
	
	#test #header {background: test;}
	#test .content_tab{background: test;}
	#test .s-profile>a{background: url(test) left top no-repeat;}
	</style>
</head>
<body>
<header id="header">
	<ul id="menu">
		<li id="guide" class="line-trigger">
			<div class="line-wrap">
				<div class="line top"></div>
				<div class="line center"></div>
				<div class="line bottom"></div>
			</div>
		</li>
		<li id="logo" class="hidden-xs">
			<a href="<?php echo __URL__;?>">
				<img src="<?php echo __STATIC__;?>/images/logo.png"/ style="height:40px;">
			</a>
	
		</li>
		<li class="pull-right">
			<ul class="hi-menu">
				<!-- 搜索 -->
				<li class="dropdown">
					<a class="waves-effect waves-light" data-toggle="dropdown" href="javascript:;">
						<i class="him-icon zmdi zmdi-search"></i>
					</a>
					<ul class="dropdown-menu dm-icon pull-right">
						<form id="search-form" class="form-inline">
							<div class="input-group">
								<input id="keywords" type="text" name="keywords" class="form-control" placeholder="搜索"/>
								<div class="input-group-btn">
									<button type="submit" class="btn btn-default"><span class="glyphicon glyphicon-search"></span></button>
								</div>
							</div>
						</form>
					</ul>
				</li>

				<li class="dropdown">
					<a class="waves-effect waves-light" data-toggle="dropdown" href="javascript:;">
						<i class="him-icon zmdi zmdi-more-vert"></i>
					</a>
					<ul class="dropdown-menu dm-icon pull-right">
						<li class="hidden-xs">
							<a class="waves-effect" data-ma-action="fullscreen" href="javascript:fullPage();"><i class="zmdi zmdi-fullscreen"></i> 全屏模式</a>
						</li>
						<li>
							<a class="waves-effect" data-ma-action="clear-localstorage" href="javascript:;"><i class="zmdi zmdi-delete"></i> 清除缓存</a>
						</li>
						<li>
						<li>
							<a class="waves-effect" href="<?php echo __URL__;?>/payservice/logout"><i class="zmdi zmdi-run"></i> 退出登录</a>
						</li>
					</ul>
				</li>
			</ul>
		</li>
	</ul>
</header>
<section id="main">
	<!-- 左侧导航区 -->
	<aside id="sidebar">
		<!-- 个人资料区 -->
		<div class="s-profile">
			<a class="waves-effect waves-light" href="javascript:;">
				<div class="sp-pic">
					<img src="http://q.qlogo.cn/g?b=qq&s=100&nk=<?php echo $user[0]['user_qq'];?>"/>
				</div>
				<div class="sp-info">
					<?php echo $_SESSION['sid']['username']?>，<script language="javaScript"> 
now = new Date(),hour = now.getHours() 
if(hour < 6){document.write("凌晨好!")}
else if (hour < 9){document.write("早上好!")}
else if (hour < 12){document.write("上午好!")}
else if (hour < 14){document.write("中午好!")}
else if (hour < 17){document.write("下午好!")}
else if (hour < 19){document.write("傍晚好!")}
else if (hour < 22){document.write("晚上好!")}
else {document.write("夜里好!")}

</script>
					<i class="zmdi zmdi-caret-down"></i>
				</div>
			</a>
			<ul class="main-menu">
				<li>
					<a class="waves-effect" href="javascript:Tab.addTab('个人资料', '<?php echo __URL__;?>/index/profile');"><i class="zmdi zmdi-account"></i> 修改资料</a>
				</li>
				<li>
					<a class="waves-effect" href="javascript:Tab.addTab('通讯管理', '<?php echo __URL__;?>/index/passageway');"><i class="zmdi zmdi-paypal-alt"></i> 管理通讯</a>
				</li>
				<li>
					<a class="waves-effect" href="<?php echo __URL__;?>/payservice/logout"><i class="zmdi zmdi-run"></i> 注销登录</a>
				</li>
			</ul>
		</div>
		<!-- /个人资料区 -->
		<!-- 菜单区 -->
		<ul class="main-menu">
			<li>
			<a class="waves-effect" href="javascript:Tab.addTab('首页', 'home');"><i class="zmdi zmdi-home"></i> 控制面板</a>
			</li>
			<li>
			<a class="waves-effect" href="javascript:Tab.addTab('友联管理', '<?php echo __URL__;?>/index/chain');"><i class="zmdi zmdi-github-alt"></i> 友联管理</a>
			</li>
			<li>
			<a class="waves-effect" href="javascript:Tab.addTab('公告管理', '<?php echo __URL__;?>/index/notice');"><i class="zmdi zmdi-layers"></i> 公告管理</a>
			</li>
			<li class="sub-menu system_menus system_1 3 toggled">
			<a class="waves-effect" href="javascript:;"><i class="zmdi zmdi-paypal-alt"></i> 商店管理</a>
			<ul style="display: block;">
				<li><a class="waves-effect" href="javascript:Tab.addTab('商品分类', '<?php echo __URL__;?>/index/category');">分类</a></li>
				<li><a class="waves-effect" href="javascript:Tab.addTab('商品管理', '<?php echo __URL__;?>/index/shop');">商品</a></li>
				<li><a class="waves-effect" href="javascript:Tab.addTab('库存管理', '<?php echo __URL__;?>/index/repertory');">库存</a></li>
				<li><a class="waves-effect" href="javascript:Tab.addTab('订单管理', '<?php echo __URL__;?>/index/order');">订单</a></li>
			</ul>
			</li>




			<li>
			<div class="upms-version">
				&copy; Force Yc 版权所有
			</div>
			</li>
		</ul>
		<!-- /菜单区 -->
	</aside>
	<!-- /左侧导航区 -->
	<section id="content">
		<div class="content_tab">
			<div class="tab_left">
				<a class="waves-effect waves-light" href="javascript:;"><i class="zmdi zmdi-chevron-left"></i></a>
			</div>
			<div class="tab_right">
				<a class="waves-effect waves-light" href="javascript:;"><i class="zmdi zmdi-chevron-right"></i></a>
			</div>
			<ul id="tabs" class="tabs">
				<li id="tab_home" data-index="home" data-closeable="false" class="cur">
					<a class="waves-effect waves-light">首页</a>
				</li>
			</ul>
		</div>
		
		<div class="content_main">
			<div id="iframe_home" class="iframe cur">
				<p><h4>Dlbrush系统[正式版](个人版) <b style="color:#c00">v <?php echo $user[0]['user_version'];?></b></h4></p>
				<br / >
				<p><h4>服务器配置</h4></p>
				<p><b>WEB组件</b>：<?php echo $_SERVER['SERVER_SOFTWARE'];?></p>
				<p><b>服务器时间</b>：<?php echo date("Y/m/d H:i:s",time());?></p>
				<p><b>MySQL版本</b>：<?php $call = Granular::MYSQL('user')->sql("select VERSION() as ver");echo $call[0]['ver'];?></p>
				<p><b>操作系统</b>：<?php echo PHP_OS; ?></p><br>

				<p><h4>本程序功能/说明</h4></p>
				<p>全自动发卡、支付宝/微信/QQ/财付通二维码收款免签约支付、批量发卡、高性能处理</p>
				<p>使用原创高质量二次元动漫版模板,小白数据库安装系统~</p>
				<p>作者留:欢迎进入交流群交流 <a href="https://jq.qq.com/?_wv=1027&k=5cgAboc">点我入群</a></p>
				<br/>
				<p><h4>关于我们</h4></p>
				<p><b>制作全套</b>：小毅毅 (QQ:2050113827）</p>
			</div>
		</div>
	</section>
</section>
<footer id="footer"></footer>

<script src="<?php echo __STATIC__;?>/plugins/jquery.1.12.4.min.js"></script>
<script src="<?php echo __STATIC__;?>/plugins/bootstrap-3.3.0/js/bootstrap.min.js"></script>
<script src="<?php echo __STATIC__;?>/plugins/waves-0.7.5/waves.min.js"></script>
<script src="<?php echo __STATIC__;?>/plugins/malihu-custom-scrollbar-plugin/jquery.mCustomScrollbar.concat.min.js"></script>
<script src="<?php echo __STATIC__;?>/plugins/BootstrapMenu.min.js"></script>
<script src="<?php echo __STATIC__;?>/plugins/device.min.js"></script>
<script src="<?php echo __STATIC__;?>/plugins/fullPage/jquery.fullPage.min.js"></script>
<script src="<?php echo __STATIC__;?>/plugins/fullPage/jquery.jdirk.min.js"></script>
<script src="<?php echo __STATIC__;?>/plugins/jquery.cookie.js"></script>

<script src="<?php echo __STATIC__;?>/js/admin.js"></script>
</body>
</html>