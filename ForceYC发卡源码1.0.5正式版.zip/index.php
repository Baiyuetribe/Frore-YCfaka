<?php
// +----------------------------------------------------------------------
// | MINET [ WE CAN DO IT JUST MINET ]
// +----------------------------------------------------------------------
// | Copyright (c) 2016 Minet All rights reserved.
// +----------------------------------------------------------------------
// | Licensed ( http://www.minet.cc/licenses/1.0 )
// +----------------------------------------------------------------------
// | Author: Minet <admin@minet.cc>
// +----------------------------------------------------------------------

//定义根目录路径
define('__ROOT__', dirname(__FILE__));
//定义工程目录名称
define('APP_NAME', 'application');

require_once './library/minet.php';

Drives::Entry(array(
        "listen"=>array(
            "module"=>false,//多模块开关
            "mount"=>false,//多控制器开关
        ),
        //绑定事件
        "bind"=>array(
            "module"=>"client",
            "mount"=>"client",
            "action"=>"index",
        ),
		//入口绑定
		"entry"=>array(
			"php"=>"index.php"
		)
    ));
?>