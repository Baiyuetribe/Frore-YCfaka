<?php
class Granular {

    //数据库方法
    static function MYSQL($DB) {
        return new mysql_server(INTO($DB));
    }
    //文件加载
    static function IMPORT($name,$array=null){
    
        if (is_array($array)){
            foreach ($array as $key=>$value){
                $$key = $value;
            }
        }
        require __RES__ . $name . ".php";
    }
    //获取客户端IP地址
    static function CLIENTIP() {
        if (getenv('HTTP_CLIENT_IP')) {
            $ip = getenv('HTTP_CLIENT_IP');
        }
        elseif (getenv('HTTP_X_FORWARDED_FOR')) {
            $ip = getenv('HTTP_X_FORWARDED_FOR');
        }
        elseif (getenv('HTTP_X_FORWARDED')) {
            $ip = getenv('HTTP_X_FORWARDED');
        }
        elseif (getenv('HTTP_FORWARDED_FOR')) {
            $ip = getenv('HTTP_FORWARDED_FOR');
    
        }
        elseif (getenv('HTTP_FORWARDED')) {
            $ip = getenv('HTTP_FORWARDED');
        }
        else {
            $ip = $_SERVER['REMOTE_ADDR'];
        }
        return $ip;
    }
    
    //得到IP的归属地
    static function IPCITY($ip){
        $data = mb_convert_encoding(file_get_contents("http://ip.ws.126.net/ipquery?ip=$ip"), 'UTF-8', 'UTF-8,GBK,GB2312,BIG5' ); ;
        preg_match("/lo=\"([\S\s]+?)\",/", $data, $d);
        preg_match("/lc=\"([\S\s]+?)\";/", $data, $b);
        return $d[1] . $b[1];
    }
    // 实例化模型
    static function MODEL($name){
        include_once __FOUND__ . $name . '.php';
        return new $name();
    }
    
    // 跳转接口
    static function INTERFACED($name){
        include_once __INTERFACE__ . $name . '.php';
        return new $name();
    }
    
    // POST_GET数据解析  $type { null : 不过滤, xss: 过滤xss, sql :过滤sql注入}
    static function REQUEST($method,$name,$type = null){
    	//post方法
    	if ($method == 'post' || $method == 'POST'){
    		//不过滤
    		if ($type == null){
    			return $_POST[$name];	
    		}
    		//xss过滤
    		if ($type == 'xss' || $type == 'XSS'){
    			return htmlspecialchars($_POST[$name]);
    		}
    		//sql过滤
    		if ($type == 'sql' || $type == 'SQL'){
    			$Granular = new Granular();
    			return $Granular->SQL_CHECK($_POST[$name]);
    		}
    		if ($type == 'script' || $type == 'SCRIPT'){
    		    //完全过滤js
    		    $var = preg_replace('/<SC?.*\>/','',$_POST[$name]);
                $var = preg_replace('/<sc?.*\>/','',$var);
                $var = preg_replace('/<sC?.*\>/','',$var);
                $var = preg_replace('/<Sc?.*\>/','',$var);
                return $var;
    		}
    	}
    	//get方法
    	if ($method == 'get' || $method == 'GET'){
    		//不过滤
    		if ($type == null){
    			return $_GET[$name];
    		}
    		//xss过滤
    		if ($type == 'xss' || $type == 'XSS'){
    			return htmlspecialchars($_GET[$name]);
    		}
    		//sql过滤
    		if ($type == 'sql' || $type == 'SQL'){
    			$Granular = new Granular();
    			return $Granular->SQL_CHECK($_GET[$name]);
    		}
    	}	
    }
    // RC4加密和解密
    static function ENCODE($data,$pwd,$action=1){
    	$Granular = new Granular();
    	if ($action == 1){
    		return base64_encode($Granular->RC4($pwd, $data));
    	}
    	if ($action == 2){
    		return $Granular->RC4($pwd, base64_decode($data));
    	}
    }
    
    //json格式化
    static function JSON($code, $msg, $array=null)
    {
    	header('Content-type: application/json'); // json
    	exit(json_encode(array(
    			"status" => $code,
    			"msg" => $msg,
    			"data" => $array
    	)));
    }
        
    // 生成树
    static function CATEGORY($data,$pId=0,$pidName='category_pid')
    {
        $tree = array();
    
            foreach ($data as $k => $v) {
                if ($v[$pidName] == $pId) {
                    $v['child'] = self::CATEGORY($data, $v['id'],$pidName);
                    $tree[] = $v;
                }
            }

        return $tree;
    }
    
    //跳转
    static function JUMP($url,$time,$msg='加载中..'){
    	echo <<<Eof
<!DOCTYPE html>
<!--[if IE 9 ]><html class="ie9"><![endif]-->
    <head>
        <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0" />
        <meta name="format-detection" content="telephone=no">
        <meta charset="UTF-8">
        <meta http-equiv='Refresh' content='$time; url=$url' />
        <style>*{font-family:'微软雅黑';font-size:12px;}</style>
        <title>$msg..</title>
        <!-- CSS -->
     
    </head>
    <body>
                   <p>{$msg}</p>
    </body>
</html>
Eof;
    	die;
    }
    
    //获取url
    static function URL()
    {
        $pageURL = 'http';
    
        if ($_SERVER["HTTPS"] == "on")
        {
            $pageURL .= "s";
        }
        $pageURL .= "://";
    
        if ($_SERVER["SERVER_PORT"] != "80")
        {
            $pageURL .= $_SERVER["SERVER_NAME"] . ":" . $_SERVER["SERVER_PORT"] . $_SERVER["REQUEST_URI"];
        }
        else
        {
            $pageURL .= $_SERVER["SERVER_NAME"] . $_SERVER["REQUEST_URI"];
        }
        return $pageURL;
    }
    
    static function STRTIP($str){
        if(get_magic_quotes_gpc())//如果get_magic_quotes_gpc()是打开的
        
        {
            $str=stripslashes($str);//将字符串进行处理
        
        }
        return $str;
    }
    //自动实例化
    static function EXAMPLE($dir,$class){
        include_once $dir;
        return new $class();
    }
    
    //RC4加密
    private function RC4 ($pwd, $data)
    {
    	$key[] ="";
    	$box[] ="";
    	 
    	$pwd_length = strlen($pwd);
    	$data_length = strlen($data);
    	 
    	for ($i = 0; $i < 256; $i++)
    	{
    		$key[$i] = ord($pwd[$i % $pwd_length]);
    		$box[$i] = $i;
    	}
    	 
    	for ($j = $i = 0; $i < 256; $i++)
    	{
    		$j = ($j + $box[$i] + $key[$i]) % 256;
    		$tmp = $box[$i];
    		$box[$i] = $box[$j];
    		$box[$j] = $tmp;
    	}
    	 
    	for ($a = $j = $i = 0; $i < $data_length; $i++)
    	{
    		$a = ($a + 1) % 256;
    		$j = ($j + $box[$a]) % 256;
    		 
    		$tmp = $box[$a];
    		$box[$a] = $box[$j];
    		$box[$j] = $tmp;
    		 
    		$k = $box[(($box[$a] + $box[$j]) % 256)];
    		$cipher .= chr(ord($data[$i]) ^ $k);
    	}
    	 
    	return $cipher;
    }
    //过滤SQL参数
    private function SQL_CHECK( $string ) {
    	//$keyword = 'select|insert|update|delete|\'|\/\*|\*|\.\.\/|\.\/|union|and|union|order|or|into|load_file|outfile';
    	//$arr = explode( '|', $keyword );
    	//$result = str_ireplace( $arr, '', $string );
    	return $string;
    }
    


    static function DIRDELETE($directory)
    {
        if (file_exists($directory)) {
            if ($dir_handle = @opendir($directory)) {
                while ($filename = readdir($dir_handle)) {
                    if ($filename != '.' && $filename != '..') {
                        $subFile = $directory . "/" . $filename;
                        if (is_dir($subFile)) {
                            self::DIRDELETE($subFile);
                        }
                        if (is_file($subFile)) {
                            unlink($subFile);
                        }
                    }
                }
                closedir($dir_handle);
                rmdir($directory);
            }
        }
    }
    

}