<?php
class Drives
{
    static public function Entry($_CONFIG)
    {
        // 屏蔽所有错误
        error_reporting(0);
        // 开启缓存页面
        session_start();
        ob_start();
        // utf-8编码设置
        header("Content-type: text/html; charset=utf-8");
        // 时区设置
        date_default_timezone_set('PRC');
        if (! is_array($_CONFIG)) exit('初始化失败!');
            // PATH_INFO 模块 :{0 : 模块名称 1 : 控制器类名称 , 2 : 需要执行的方法 , 3 :[ GET参数 ] }
        @$INFO = explode('/', ltrim($_SERVER['PATH_INFO'], "/"));
        $mount_info = 0;
        $action_info = 0;
        // 定义模块名称
        if ($_CONFIG['listen']['module'] == true) {
            // 开启模块模式
            $MODULE = $INFO[0] ? $INFO[0] : $_CONFIG['bind']['module'];
            // 定义控制器数量
            $mount_info = 1;
        } else {
            // 当关闭模块模式，自动执行默认模块
            $MODULE = $_CONFIG['bind']['module'];
            // 定义控制器数量
            $mount_info = 0;
        }
        // 定义控制器
        if ($_CONFIG['listen']['mount'] == true) {
            // 当开启多控制器的时候则执行URL上的控制器
            $MOUNT = $INFO[$mount_info] ? $INFO[$mount_info] : $_CONFIG['bind']['mount'];
        } else {
            // 当关闭多控制器的时候则不去执行URL上的控制器,直接转为单控制器
            $MOUNT = $_CONFIG['bind']['mount'];
        }
        // 定义方法数量
        if ($_CONFIG['listen']['module'] == true && $_CONFIG['listen']['mount'] == true) {
            $action_info = 2;
        }
        if ($_CONFIG['listen']['module'] == false && $_CONFIG['listen']['mount'] == true) {
            $action_info = 1;
        }
        if ($_CONFIG['listen']['module'] == true && $_CONFIG['listen']['mount'] == false) {
            $action_info = 1;
        }
        if ($_CONFIG['listen']['module'] == false && $_CONFIG['listen']['mount'] == false) {
            $action_info = 0;
        }
        // 定义执行方法
        $ACTION = $INFO[$action_info] ? $INFO[$action_info] : $_CONFIG['bind']['action'];
        
        // URL算法 {当GET长度为3的时候}
        if ($_CONFIG['listen']['module'] == true && $_CONFIG['listen']['mount'] == true) {
            // 循环加入$_GET
            for ($i = 3; $i < count($INFO); $i ++) {
                if ($i % 2 != 0) {
                    $_GET["$INFO[$i]"] = $INFO[$i + 1];
                }
            }
        }
        // URL算法 {当GET长度为2的时候}
        if ($_CONFIG['listen']['module'] == true && $_CONFIG['listen']['mount'] == false || $_CONFIG['listen']['module'] == false && $_CONFIG['listen']['mount'] == true) {
            for ($i = 2; $i < count($INFO); $i ++) {
                if ($i % 2 == 0) {
                    $_GET["{$INFO[$i]}"] = $INFO[$i + 1];
                }
            }
        }
        // URL算法 {当GET长度为1的时候}
        if ($_CONFIG['listen']['module'] == false && $_CONFIG['listen']['mount'] == false) {
            // 循环加入$_GET
            for ($i = 1; $i < count($INFO); $i ++) {
                if ($i % 2 != 0) {
                    $_GET["$INFO[$i]"] = $INFO[$i + 1];
                }
            }
        }
        //定义静态目录地址
        define('__STATIC__', str_replace($_CONFIG['entry']['php'], '', $_SERVER['SCRIPT_NAME']).APP_NAME."/{$MODULE}/look/theme");
        //定义资源静态目录
        define('__THEME__', str_replace($_CONFIG['entry']['php'], '', $_SERVER['SCRIPT_NAME']).APP_NAME."/{$MODULE}/look/resource");
        //定义当前网站端口
        $HOST_PROT = $_SERVER['SERVER_PORT'] != 80 ? ":". $_SERVER['SERVER_PORT'] : '';
        //定义URL路径
        define('__URL__', "http://" . $_SERVER['SERVER_NAME'] . $HOST_PROT . str_replace('index.php', '', $_SERVER['SCRIPT_NAME']));
        // 定义html模板文件绝对地址
        define('__RES__', __ROOT__ .  "/".APP_NAME."/{$MODULE}/look/resource/");
        // 定义found路径
        define('__FOUND__', __ROOT__ .  "/".APP_NAME."/{$MODULE}/found/");
        // 定义当前使用的ACTION方法
        define('__ACTION__', $ACTION);
        // 定义 config 初始化ID
        define('__CID__', 1);
        // 定义 缓存目录 [cache]
        define('__CACHE__', __ROOT__ .  "/".APP_NAME."/{$MODULE}/cache/");
        // 定义 接口目录 [interface]
        define('__INTERFACE__', __ROOT__ . "/interface/");
        // 载入数据配置文件
        include_once __ROOT__ . '/config.php';
        // 载入mysql支持库
        include_once __ROOT__ . '/library/mysql.php';
        // 加载Granular
        include_once __ROOT__ . '/library/granular.php';
        // 加载DIRECT类文件
        include_once __ROOT__ . "/". APP_NAME ."/{$MODULE}/mount/{$MOUNT}.php";
        // 实例化DIRECT类
        $INSTANCE = new $MOUNT();
        // 访问方法
        $INSTANCE->$ACTION();
    }
}
?>
