SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for wintpay_category
-- ----------------------------
DROP TABLE IF EXISTS `wintpay_category`;
CREATE TABLE `wintpay_category` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `category_name` varchar(64) DEFAULT NULL COMMENT '名称',
  `category_uniqid` varchar(64) NOT NULL DEFAULT '' COMMENT '唯一ID',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=16 DEFAULT CHARSET=utf8 COMMENT='分类';

-- ----------------------------
-- Records of wintpay_category
-- ----------------------------
INSERT INTO `wintpay_category` VALUES ('15', ' 测试分类', '92B3506093');

-- ----------------------------
-- Table structure for wintpay_chain
-- ----------------------------
DROP TABLE IF EXISTS `wintpay_chain`;
CREATE TABLE `wintpay_chain` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `chain_name` varchar(255) DEFAULT NULL,
  `chain_http` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COMMENT='友链管理';

-- ----------------------------
-- Records of wintpay_chain
-- ----------------------------
INSERT INTO `wintpay_chain` VALUES ('3', 'YcPay交流群', 'https://jq.qq.com/?_wv=1027&amp;k=5m84SRI');
INSERT INTO `wintpay_chain` VALUES ('4', '萌社区', 'https://www.acgshe.com/');

-- ----------------------------
-- Table structure for wintpay_coupon
-- ----------------------------
DROP TABLE IF EXISTS `wintpay_coupon`;
CREATE TABLE `wintpay_coupon` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `coupon_volume` varchar(32) NOT NULL DEFAULT '0' COMMENT '优惠卷',
  `coupon_shopid` int(11) NOT NULL DEFAULT '0' COMMENT '商品id 0 为 全部通用',
  `coupon_state` tinyint(1) NOT NULL DEFAULT '1' COMMENT '1未使用 2已使用',
  `coupon_moeny` decimal(10,2) NOT NULL DEFAULT '0.00' COMMENT '金额',
  `coupon_addtime` varchar(18) NOT NULL DEFAULT '0' COMMENT '生成时间',
  `coupon_usetime` varchar(18) DEFAULT '0' COMMENT '使用时间',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=134 DEFAULT CHARSET=utf8 COMMENT='优惠卷';

-- ----------------------------
-- Records of wintpay_coupon
-- ----------------------------

-- ----------------------------
-- Table structure for wintpay_link
-- ----------------------------
DROP TABLE IF EXISTS `wintpay_link`;
CREATE TABLE `wintpay_link` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `link_name` text NOT NULL COMMENT '友链名称',
  `link_http` varchar(255) NOT NULL DEFAULT '/' COMMENT '友链地址',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='友链管理';

-- ----------------------------
-- Records of wintpay_link
-- ----------------------------

-- ----------------------------
-- Table structure for wintpay_notice
-- ----------------------------
DROP TABLE IF EXISTS `wintpay_notice`;
CREATE TABLE `wintpay_notice` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `notice_text` varchar(255) DEFAULT NULL COMMENT '公告内容',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8 COMMENT='公告';

-- ----------------------------
-- Records of wintpay_notice
-- ----------------------------
INSERT INTO `wintpay_notice` VALUES ('2', '欢迎使用Force Yc Pay发卡源码,本源码为个人发卡版');
INSERT INTO `wintpay_notice` VALUES ('3', '当前版本:Force Dlbrush v1.0.5[正式版] 程序类型:个人发卡源码');
INSERT INTO `wintpay_notice` VALUES ('4', '本发卡网不支持在线提交刷钻订单,请注意这是自动发布卡密');
INSERT INTO `wintpay_notice` VALUES ('5', '本发卡网由于是全自动,添加卡密商品后无需人工操作即可~');
INSERT INTO `wintpay_notice` VALUES ('6', '如果对软件发现BUG或者一些问题请加入YcPay交流群 ');

-- ----------------------------
-- Table structure for wintpay_order
-- ----------------------------
DROP TABLE IF EXISTS `wintpay_order`;
CREATE TABLE `wintpay_order` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `order_number` varchar(64) NOT NULL DEFAULT '' COMMENT '订单号',
  `order_shopid` int(11) NOT NULL DEFAULT '0' COMMENT '商品id',
  `order_info` text COMMENT '订单信息',
  `order_creatime` varchar(18) NOT NULL DEFAULT '' COMMENT '订单创建时间',
  `order_paytime` varchar(18) DEFAULT '0' COMMENT '订单支付时间',
  `order_payx` varchar(60) DEFAULT NULL COMMENT '支付方式',
  `order_moeny` decimal(10,2) DEFAULT '0.00' COMMENT '订单金额',
  `order_state` tinyint(1) NOT NULL DEFAULT '1' COMMENT '状态 1 未支付 2 已支付 3已超时',
  `order_contact` varchar(30) NOT NULL DEFAULT '0' COMMENT '联系方式',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=245 DEFAULT CHARSET=utf8 COMMENT='订单';

-- ----------------------------
-- Records of wintpay_order
-- ----------------------------
INSERT INTO `wintpay_order` VALUES ('244', '2018101511295119105', '17', '1', '1539574191', '0', null, '1.00', '1', '15559599004');

-- ----------------------------
-- Table structure for wintpay_passageway
-- ----------------------------
DROP TABLE IF EXISTS `wintpay_passageway`;
CREATE TABLE `wintpay_passageway` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `passageway_titile` varchar(255) DEFAULT NULL COMMENT '标题名称',
  `passageway_website` varchar(255) NOT NULL DEFAULT '' COMMENT '通讯网站',
  `passageway_username` varchar(255) NOT NULL DEFAULT '' COMMENT '通讯用户',
  `passageway_key` varchar(255) DEFAULT NULL COMMENT '通讯钥匙',
  `passageway_ctime` varchar(255) DEFAULT NULL COMMENT '创建时间',
  `passageway_state` varchar(255) NOT NULL DEFAULT '2' COMMENT '状态判断 1开启 2关闭',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COMMENT='支付通道';

-- ----------------------------
-- Records of wintpay_passageway
-- ----------------------------
INSERT INTO `wintpay_passageway` VALUES ('3', '格式演示', 'http://127.0.0.1/', '10254', '5wqd4q561d2qw368wsd45w110dsa', '1538410020', '1');

-- ----------------------------
-- Table structure for wintpay_qrcode
-- ----------------------------
DROP TABLE IF EXISTS `wintpay_qrcode`;
CREATE TABLE `wintpay_qrcode` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `qrcode_money` decimal(10,2) NOT NULL DEFAULT '0.00' COMMENT '通道金额',
  `qrcode_cdmoney` decimal(10,2) NOT NULL DEFAULT '0.00' COMMENT '真实二维码金额',
  `qrcode_createTime` varchar(16) DEFAULT '0' COMMENT '通道创建时间',
  `qrcode_wechat` varchar(255) DEFAULT NULL COMMENT '微信二维码地址',
  `qrcode_alipay` varchar(255) DEFAULT NULL COMMENT '支付宝二维码地址',
  `qrcode_wallet` varchar(255) DEFAULT NULL COMMENT 'QQ钱包二维码',
  `qrcode_heartbeat` varchar(16) DEFAULT '0' COMMENT '心跳',
  PRIMARY KEY (`id`),
  UNIQUE KEY `qrcode_cdmoney` (`qrcode_cdmoney`)
) ENGINE=MyISAM AUTO_INCREMENT=12 DEFAULT CHARSET=utf8 COMMENT='二维码';

-- ----------------------------
-- Records of wintpay_qrcode
-- ----------------------------

-- ----------------------------
-- Table structure for wintpay_repertory
-- ----------------------------
DROP TABLE IF EXISTS `wintpay_repertory`;
CREATE TABLE `wintpay_repertory` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `repertory_shopid` int(11) NOT NULL DEFAULT '0' COMMENT '商品ID',
  `repertory_card` varchar(255) NOT NULL DEFAULT '' COMMENT '卡密',
  `repertory_state` tinyint(1) NOT NULL DEFAULT '1' COMMENT '1 正常 2 已出售',
  `repertory_contact` varchar(32) NOT NULL DEFAULT '0' COMMENT '购买者联系方式',
  `repertory_addtime` varchar(18) NOT NULL DEFAULT '0' COMMENT '添加时间',
  `repertory_paytime` varchar(18) DEFAULT '0' COMMENT '购买时间',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=446 DEFAULT CHARSET=utf8 COMMENT='库存';

-- ----------------------------
-- Records of wintpay_repertory
-- ----------------------------
INSERT INTO `wintpay_repertory` VALUES ('438', '17', 's', '1', '0', '1538412524', '0');
INSERT INTO `wintpay_repertory` VALUES ('439', '17', 's', '1', '0', '1538412524', '0');
INSERT INTO `wintpay_repertory` VALUES ('440', '17', 's', '1', '0', '1538412524', '0');
INSERT INTO `wintpay_repertory` VALUES ('441', '17', 's', '1', '0', '1538412524', '0');
INSERT INTO `wintpay_repertory` VALUES ('442', '17', 's', '1', '0', '1538412524', '0');
INSERT INTO `wintpay_repertory` VALUES ('443', '17', 's', '1', '0', '1538412524', '0');
INSERT INTO `wintpay_repertory` VALUES ('444', '17', 's', '1', '0', '1538412524', '0');
INSERT INTO `wintpay_repertory` VALUES ('445', '17', 's', '1', '0', '1538412524', '0');

-- ----------------------------
-- Table structure for wintpay_shop
-- ----------------------------
DROP TABLE IF EXISTS `wintpay_shop`;
CREATE TABLE `wintpay_shop` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `shop_name` varchar(60) NOT NULL DEFAULT '' COMMENT '商品名称',
  `shop_price` decimal(10,2) NOT NULL DEFAULT '0.00' COMMENT '出售价格',
  `shop_rank` int(11) NOT NULL DEFAULT '0' COMMENT '商品排序',
  `shop_warning` int(11) NOT NULL DEFAULT '0' COMMENT '库存预警',
  `shop_cateid` int(11) NOT NULL DEFAULT '0' COMMENT '商品分类ID',
  `shop_uniqid` varchar(32) NOT NULL DEFAULT '' COMMENT '唯一id',
  `shop_cost` varchar(255) NOT NULL DEFAULT '0' COMMENT '商品成本',
  `shop_text` varchar(255) DEFAULT NULL COMMENT '商品说明',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=18 DEFAULT CHARSET=utf8 COMMENT='商品';

-- ----------------------------
-- Records of wintpay_shop
-- ----------------------------
INSERT INTO `wintpay_shop` VALUES ('17', '测试通道1s', '1.00', '0', '100', '15', 'A628A8FE40', '1', '测试商品而已QWQ');

-- ----------------------------
-- Table structure for wintpay_user
-- ----------------------------
DROP TABLE IF EXISTS `wintpay_user`;
CREATE TABLE `wintpay_user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_username` varchar(26) NOT NULL DEFAULT 'admin' COMMENT '账号',
  `user_password` varchar(64) NOT NULL DEFAULT '' COMMENT '密码',
  `user_token` varchar(16) DEFAULT '',
  `user_qq` varchar(16) NOT NULL DEFAULT '2050113827' COMMENT 'QQ号码',
  `user_title` varchar(255) DEFAULT 'ycpay_你的支付专家!',
  `user_keyword` varchar(255) DEFAULT 'ycpay,支付宝,微信,发卡网' COMMENT '关键词',
  `user_description` varchar(255) NOT NULL DEFAULT 'ycpay发卡,你的支付专家' COMMENT '简介',
  `user_logo` varchar(255) DEFAULT '' COMMENT '网站icon地址',
  `user_version` varchar(255) NOT NULL DEFAULT '' COMMENT '1.0.5',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of wintpay_user
-- ----------------------------
INSERT INTO `wintpay_user` VALUES ('1', 'admin', 'd093a1869d22fd41b29fdfdd303a4f43', '353600', '2050113827', 'YcPay_你的支付专家!', 'YcPay,支付宝,微信,发卡网', 'YcPay发卡,你的支付专家', 'upload/image/201807021553288777349.jpg', '1.0.5');
