<?php
//定义根目录路径
define('__ROOT__', dirname(__FILE__));
//定义upload路径
define('__UPLOAD__', './upload/');
//定义工程目录名称
define('APP_NAME', 'application');

require_once './library/minet.php';

Drives::Entry(array(
        "listen"=>array(
            "module"=>false,//多模块开关
            "mount"=>true,//多控制器开关
        ),
        //绑定事件
        "bind"=>array(
            "module"=>"operating",
            "mount"=>"index",
            "action"=>"login",
        ),
		//入口绑定
		"entry"=>array(
			"php"=>"admin.php"
		)
    ));
?>