<?php
function INTO($DB){
    return array(
        "HOST" => "127.0.0.1",//数据库服务器
        "PORT" => '3306',//数据库端口
        "USER" => "",//用户名
        "PASS" => "",//密码
        "DB" => "",//数据库名称
        "CHARSET" => "utf8",//数据库编码
        "PREFIX" => "wintpay_",//表前缀请勿修改
        "TABLE" => $DB //该项不能更改
    );
}
?>